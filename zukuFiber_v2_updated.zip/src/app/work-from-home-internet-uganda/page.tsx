import type { Metadata } from 'next';
import Link from 'next/link';

export function generateMetadata(): Metadata {
  return {
    title: 'Best Internet for Working From Home Uganda 2026 | Zuku Fiber',
    description: 'Best internet for working from home in Uganda 2026. Zuku Fiber delivers zero-throttle unlimited fiber from UGX 75,000/mo — perfect for video calls and remote work.',
    keywords: [
      'best internet for working from home Uganda',
      'work from home internet Uganda',
      'remote work internet Kampala',
      'best internet in Uganda',
      'unlimited internet Uganda',
      'fiber internet Kampala',
      'best fiber internet Uganda',
      'fastest internet Uganda',
      'best WiFi in Kampala',
      'home internet Uganda',
      'internet without data cap Uganda',
      'best ISP Uganda',
      'Zuku Fiber Uganda',
      'best internet provider Uganda',
      'best unlimited internet Uganda 2026',
    ],
    openGraph: {
      title: 'Best Internet for Working From Home Uganda 2026 | Zuku Fiber',
      description: 'Zero-throttle fiber internet for remote workers in Uganda. Symmetrical speeds, 99.9% uptime, 5ms latency. From UGX 75,000/month with free installation.',
      url: 'https://zukufiberuganda.vercel.app/work-from-home-internet-uganda',
      siteName: 'Zuku Fiber Uganda',
    },
    alternates: { canonical: 'https://zukufiberuganda.vercel.app/work-from-home-internet-uganda' },
  };
}

export default function WorkFromHomeInternetUgandaPage() {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@graph': [
      {
        '@type': 'LocalBusiness',
        name: 'Zuku Fiber Uganda',
        url: 'https://zukufiberuganda.vercel.app/',
        telephone: '0775 260 196',
        address: { '@type': 'PostalAddress', streetAddress: 'Diamond Trust Building', addressLocality: 'Kampala', addressCountry: 'Uganda' },
        geo: { '@type': 'GeoCoordinates', latitude: 0.3476, longitude: 32.5825 },
      },
      {
        '@type': 'BreadcrumbList',
        itemListElement: [
          { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://zukufiberuganda.vercel.app/' },
          { '@type': 'ListItem', position: 2, name: 'Work From Home Internet Uganda', item: 'https://zukufiberuganda.vercel.app/work-from-home-internet-uganda' },
        ],
      },
      {
        '@type': 'FAQPage',
        mainEntity: [
          { '@type': 'Question', name: 'What is the best internet for working from home in Uganda?', acceptedAnswer: { '@type': 'Answer', text: 'Zuku Fiber is the best internet for working from home in Uganda. Its symmetrical speeds, 5ms latency, zero throttling, and 99.9% uptime make it ideal for video calls, cloud work, and large file transfers.' } },
          { '@type': 'Question', name: 'Does Zuku Fiber work well for Zoom calls in Uganda?', acceptedAnswer: { '@type': 'Answer', text: 'Yes. Zuku Fiber delivers symmetrical speeds (equal upload and download) and 5ms latency, which eliminates video call lag and dropped calls. Subscribers report zero dropped calls even on the 25 Mbps plan.' } },
          { '@type': 'Question', name: 'Is fiber internet good enough for remote work in Uganda?', acceptedAnswer: { '@type': 'Answer', text: 'Fiber is the gold standard for remote work. Zuku Fiber\'s dedicated fiber optic connection doesn\'t slow down during busy hours, unlike mobile broadband from MTN or Airtel.' } },
          { '@type': 'Question', name: 'Which internet plan is best for video conferencing in Uganda?', acceptedAnswer: { '@type': 'Answer', text: 'The 50 Mbps plan at UGX 89,400/month is ideal for most remote workers. It supports multiple simultaneous video calls, cloud backups, and file transfers without any slowdown.' } },
          { '@type': 'Question', name: 'Does working from home internet in Uganda have data caps?', acceptedAnswer: { '@type': 'Answer', text: 'Not with Zuku Fiber. All plans are truly unlimited — no data caps, no fair usage policy, and no throttling even if you use hundreds of gigabytes per month for work.' } },
          { '@type': 'Question', name: 'What upload speed do I need for remote work in Uganda?', acceptedAnswer: { '@type': 'Answer', text: 'For video calls you need at least 5 Mbps upload. Zuku Fiber delivers symmetrical speeds — so a 25 Mbps plan gives you 25 Mbps upload too, far more than enough for HD video conferencing.' } },
          { '@type': 'Question', name: 'Can I run my business from home in Kampala with Zuku Fiber?', acceptedAnswer: { '@type': 'Answer', text: 'Absolutely. Many businesses in Kololo, Ntinda, Naguru, and Bugolobi operate entirely from home on Zuku Fiber. The 100 Mbps or 200 Mbps plans are particularly popular for small businesses.' } },
          { '@type': 'Question', name: 'What happens if my work internet goes down in Uganda?', acceptedAnswer: { '@type': 'Answer', text: 'Zuku Fiber has a 99.9% uptime SLA. If your connection goes down, our 24/7 Kampala-based engineers respond quickly — most issues resolved within 30 minutes.' } },
        ],
      },
    ],
  };

  return (
    <main className="min-h-screen bg-[#0a0f1e] text-gray-300 font-sans selection:bg-blue-500/30">

      <section className="relative w-full pt-32 pb-20 overflow-hidden bg-gradient-to-b from-blue-900/20 to-[#0a0f1e]">
        <div className="max-w-7xl mx-auto px-4 relative z-10 flex flex-col items-center text-center">
          <div className="inline-block bg-white/10 text-white text-sm tracking-wide uppercase rounded-full px-4 py-1.5 mb-6 border border-white/10 backdrop-blur-sm">
            💼 Built for Remote Workers in Kampala
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight max-w-5xl tracking-tight">
            Best Internet for{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-blue-600">
              Working From Home
            </span>{' '}
            Uganda 2026
          </h1>
          <p className="text-xl text-gray-200 mb-8 max-w-3xl">
            Zero throttling. Symmetrical speeds. 5ms latency. 99.9% uptime. Zuku Fiber is the only internet Uganda remote workers can truly rely on — from UGX 75,000/month.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 mb-12">
            <Link href="https://wa.me/2560775260196" className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-8 py-4 font-semibold transition-all shadow-lg shadow-blue-600/20 text-lg">
              Get Set Up via WhatsApp
            </Link>
            <Link href="/#plans" className="border border-white/20 text-white hover:bg-white/10 rounded-lg px-8 py-4 font-semibold transition-all text-lg">
              View Plans
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
            {[
              { val: '5ms', label: 'Latency' },
              { val: '99.9%', label: 'Uptime SLA' },
              { val: 'Symmetrical', label: 'Upload = Download' },
              { val: '0 Caps', label: 'Truly Unlimited' },
            ].map(s => (
              <div key={s.label} className="bg-white/5 border border-white/10 rounded-xl p-4 text-center">
                <div className="text-xl font-bold text-white">{s.val}</div>
                <div className="text-xs text-gray-400 mt-1">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-blue-600/10 rounded-full blur-[120px] -z-10 pointer-events-none" />
      </section>

      <section className="py-24 max-w-7xl mx-auto px-4">
        <div className="text-center mb-16 max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Why Remote Workers Choose Zuku Fiber</h2>
          <p className="text-gray-400 text-lg">These are the five technical requirements for serious remote work internet — and how Zuku Fiber meets every one.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            { icon: '📹', title: 'Crystal-Clear Video Calls', body: 'With 5ms latency and symmetrical speeds, Zoom, Google Meet, and Microsoft Teams work perfectly. Subscribers working remotely for UK and US companies report zero dropped calls.' },
            { icon: '☁️', title: 'Fast Cloud Backups & Uploads', body: 'Symmetrical fiber means cloud backup speeds match your download speeds. A 1GB Google Drive upload that takes 30 minutes on mobile broadband finishes in under 2 minutes.' },
            { icon: '🔌', title: 'No Downtime During Work Hours', body: 'Our 99.9% uptime SLA is guaranteed. Kampala-based engineers monitor our network 24/7 and resolve most issues within 30 minutes — so your workday is never interrupted.' },
            { icon: '🚫', title: 'No Data Caps for Heavy Users', body: 'Remote workers regularly use 100–500 GB per month. Our internet without data cap Uganda policy means you\'re never throttled or charged extra regardless of how much data you use.' },
            { icon: '🔒', title: 'Secure Network by Default', body: 'DDoS protection and encrypted DNS are built into every Zuku connection. Work with sensitive client data without worrying about network-level attacks.' },
            { icon: '📞', title: 'Real Support When You Need It', body: '24/7 Kampala-based engineers — not an overseas call centre. If something goes wrong at 2 AM before a morning deadline, someone local is on the line.' },
          ].map(f => (
            <div key={f.title} className="bg-white/5 border border-white/10 rounded-2xl p-8 hover:bg-white/[0.08] transition-colors">
              <div className="text-4xl mb-4">{f.icon}</div>
              <h3 className="text-xl font-bold text-white mb-3">{f.title}</h3>
              <p className="text-gray-400 leading-relaxed">{f.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="py-16 bg-black/40 border-y border-white/5">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-white mb-4 text-center">Which Plan Should Remote Workers Choose?</h2>
          <p className="text-center text-gray-400 mb-12">Based on what you do for work, here&apos;s our recommendation.</p>
          <div className="space-y-4">
            {[
              { plan: '25 Mbps — UGX 75,000/mo', who: 'Solo freelancers: writing, design, email', detail: 'More than enough for solo remote work. Supports HD video calls, file uploads, and cloud apps simultaneously.' },
              { plan: '50 Mbps — UGX 89,400/mo ★ Most Popular', who: 'Remote employees on daily video calls', detail: 'The sweet spot for most remote workers in Kampala. Handles multiple simultaneous video calls, large file transfers, and background cloud sync without any slowdown.' },
              { plan: '100 Mbps — UGX 110,000/mo', who: 'Developers, video editors, and heavy cloud users', detail: 'Perfect for uploading large video files, running development servers, or working with large datasets. Consistently fast speeds even with a full smart home setup.' },
              { plan: '200 Mbps — UGX 199,000/mo', who: 'Home offices with multiple remote workers', detail: 'Ideal if multiple people in your household work remotely simultaneously. Each person gets a full fast connection with no contention.' },
            ].map(item => (
              <div key={item.plan} className="bg-white/5 border border-white/10 rounded-xl p-6 hover:bg-white/[0.08] transition-colors">
                <div className="font-bold text-white mb-1">{item.plan}</div>
                <div className="text-sm text-blue-400 font-medium mb-2">👤 Best for: {item.who}</div>
                <p className="text-gray-400 text-sm leading-relaxed">{item.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 max-w-7xl mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-white mb-8 text-center">Real Remote Workers in Kampala Share Their Experience</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              { quote: 'I work remotely for a UK tech company. The 99.9% uptime is real — my video calls have not dropped once since I switched to the 100 Mbps plan six months ago.', name: 'Sarah K.', role: 'Software Engineer', area: 'Kololo' },
              { quote: 'Switching to Zuku Fiber transformed my workflow. Cloud backups that took hours now finish in minutes. The symmetrical speeds made the biggest difference.', name: 'David M.', role: 'Operations Manager', area: 'Bugolobi' },
              { quote: 'I run a virtual assistant business from Ntinda serving clients in Europe. Zuku is the only provider I trust for client calls. Never a dropped call in eight months.', name: 'Agnes N.', role: 'Virtual Assistant, Ntinda', area: 'Ntinda' },
              { quote: 'As a freelance developer, upload speed matters as much as download. Zuku\'s symmetrical connection changed everything — pushing to GitHub is instant.', name: 'Brian T.', role: 'Freelance Developer', area: 'Naguru' },
            ].map(t => (
              <div key={t.name} className="bg-white/5 border border-white/10 rounded-2xl p-8">
                <div className="text-yellow-400 mb-4 text-lg">★★★★★</div>
                <p className="text-gray-300 leading-relaxed mb-6 italic">&quot;{t.quote}&quot;</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-600/30 flex items-center justify-center font-bold text-white text-sm">{t.name.charAt(0)}</div>
                  <div>
                    <div className="font-semibold text-white text-sm">{t.name}</div>
                    <div className="text-xs text-gray-400">{t.role} · {t.area}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-black/40 border-t border-white/5">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-white mb-12 text-center">Remote Work Internet FAQs</h2>
          <div className="space-y-4">
            {[
              { q: 'What is the best internet for working from home in Uganda?', a: 'Zuku Fiber is the best internet for working from home in Uganda. Its symmetrical speeds, 5ms latency, zero throttling, and 99.9% uptime make it ideal for video calls, cloud work, and large file transfers.' },
              { q: 'Does Zuku Fiber work well for Zoom calls in Uganda?', a: 'Yes. Zuku Fiber delivers symmetrical speeds (equal upload and download) and 5ms latency, which eliminates video call lag and dropped calls. Subscribers report zero dropped calls even on the 25 Mbps plan.' },
              { q: 'Is fiber internet good enough for remote work in Uganda?', a: 'Fiber is the gold standard for remote work. Zuku Fiber\'s dedicated fiber optic connection doesn\'t slow down during busy hours, unlike mobile broadband from MTN or Airtel.' },
              { q: 'Which internet plan is best for video conferencing in Uganda?', a: 'The 50 Mbps plan at UGX 89,400/month is ideal for most remote workers. It supports multiple simultaneous video calls, cloud backups, and file transfers without any slowdown.' },
              { q: 'Does working from home internet in Uganda have data caps?', a: 'Not with Zuku Fiber. All plans are truly unlimited — no data caps, no fair usage policy, and no throttling even if you use hundreds of gigabytes per month for work.' },
              { q: 'What upload speed do I need for remote work in Uganda?', a: 'For video calls you need at least 5 Mbps upload. Zuku Fiber delivers symmetrical speeds — a 25 Mbps plan gives you 25 Mbps upload too, far more than enough for HD video conferencing.' },
              { q: 'Can I run my business from home in Kampala with Zuku Fiber?', a: 'Absolutely. Many businesses in Kololo, Ntinda, Naguru, and Bugolobi operate entirely from home on Zuku Fiber. The 100 Mbps or 200 Mbps plans are particularly popular for small businesses.' },
              { q: 'What happens if my work internet goes down in Uganda?', a: 'Zuku Fiber has a 99.9% uptime SLA. If your connection goes down, our 24/7 Kampala-based engineers respond quickly — most issues are resolved within 30 minutes.' },
            ].map(faq => (
              <details key={faq.q} className="group bg-white/5 border border-white/10 rounded-xl overflow-hidden [&_summary::-webkit-details-marker]:hidden">
                <summary className="flex items-center justify-between cursor-pointer p-6 font-semibold text-white hover:bg-white/[0.07] transition-colors">
                  <span className="pr-4">{faq.q}</span>
                  <span className="transition group-open:rotate-180 bg-white/10 rounded-full p-1 shrink-0">
                    <svg fill="none" height="20" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5" width="20"><path d="M6 9l6 6 6-6" /></svg>
                  </span>
                </summary>
                <div className="px-6 pb-6 pt-2 text-gray-400 leading-relaxed border-t border-white/5">{faq.a}</div>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className="relative py-28 overflow-hidden bg-blue-900 border-t border-blue-500/20 text-center">
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0f1e] to-transparent opacity-80" />
        <div className="relative max-w-4xl mx-auto px-4 z-10">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Your career deserves internet that keeps up.</h2>
          <p className="text-xl text-blue-100 mb-10 max-w-2xl mx-auto">
            Join thousands of remote workers across Kampala who never worry about dropped calls or slow uploads. Free installation. No contracts. Same-day activation.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="https://wa.me/2560775260196" className="bg-white text-blue-900 hover:bg-gray-100 rounded-lg px-8 py-4 font-bold shadow-xl text-lg transition-all hover:-translate-y-0.5">Sign Up via WhatsApp</Link>
            <Link href="tel:+2560775260196" className="border border-white/30 text-white hover:bg-white/10 rounded-lg px-8 py-4 font-semibold text-lg transition-all">Call 0775 260 196</Link>
          </div>
        </div>
      </section>

      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
    </main>
  );
}
