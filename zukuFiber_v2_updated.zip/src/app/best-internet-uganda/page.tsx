import type { Metadata } from 'next';
import Link from 'next/link';

export function generateMetadata(): Metadata {
  return {
    title: 'Best Internet Providers in Uganda 2026 | Zuku Fiber',
    description: 'Compare the best internet providers in Uganda 2026. Zuku Fiber offers unlimited fiber from UGX 75,000/month — no caps, no throttling. Free install included.',
    keywords: [
      'best internet in Uganda',
      'best internet provider Uganda',
      'fastest internet Uganda',
      'best fiber internet Uganda',
      'unlimited internet Uganda',
      'best WiFi in Kampala',
      'cheapest internet bundles Uganda',
      'home internet Uganda',
      'fiber internet Kampala',
      'internet providers Uganda comparison',
      'best internet for working from home Uganda',
      'Airtel vs MTN vs Zuku Uganda',
      'best unlimited internet Uganda 2026',
      'internet in Kampala',
      'best ISP Uganda',
    ],
    openGraph: {
      title: 'Best Internet Providers in Uganda 2026 | Zuku Fiber',
      description: 'Compare the best internet providers in Uganda 2026. Zuku Fiber offers unlimited fiber from UGX 75,000/month — no caps, no throttling.',
      url: 'https://zukufiberuganda.vercel.app/best-internet-uganda',
      siteName: 'Zuku Fiber Uganda',
    },
    alternates: {
      canonical: 'https://zukufiberuganda.vercel.app/best-internet-uganda',
    },
  };
}

export default function BestInternetUgandaPage() {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@graph': [
      {
        '@type': 'LocalBusiness',
        name: 'Zuku Fiber Uganda',
        url: 'https://zukufiberuganda.vercel.app/',
        telephone: '0775 260 196',
        address: {
          '@type': 'PostalAddress',
          streetAddress: 'Diamond Trust Building',
          addressLocality: 'Kampala',
          addressCountry: 'Uganda',
        },
        geo: { '@type': 'GeoCoordinates', latitude: 0.3476, longitude: 32.5825 },
      },
      {
        '@type': 'BreadcrumbList',
        itemListElement: [
          { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://zukufiberuganda.vercel.app/' },
          { '@type': 'ListItem', position: 2, name: 'Best Internet Uganda', item: 'https://zukufiberuganda.vercel.app/best-internet-uganda' },
        ],
      },
      {
        '@type': 'FAQPage',
        mainEntity: [
          { '@type': 'Question', name: 'Which internet is best in Uganda?', acceptedAnswer: { '@type': 'Answer', text: 'Zuku Fiber is the best internet in Uganda for home use, offering true unlimited fiber with no data caps, 99.9% uptime, and symmetrical speeds from UGX 75,000/month.' } },
          { '@type': 'Question', name: 'What is the cheapest internet in Uganda?', acceptedAnswer: { '@type': 'Answer', text: 'Zuku Fiber offers the cheapest unlimited fiber internet in Uganda starting at UGX 75,000/month for 25 Mbps — with free installation and no contracts.' } },
          { '@type': 'Question', name: 'Which ISP is fastest in Uganda?', acceptedAnswer: { '@type': 'Answer', text: 'Zuku Fiber delivers the fastest home internet Uganda offers, with symmetrical speeds up to 200 Mbps and just 5ms latency on a dedicated fiber optic network.' } },
          { '@type': 'Question', name: 'Does Zuku Fiber have data caps?', acceptedAnswer: { '@type': 'Answer', text: 'No. Zuku Fiber Uganda has strictly unlimited plans with zero data caps and no throttling at any time of day.' } },
          { '@type': 'Question', name: 'How much is fiber internet in Uganda?', acceptedAnswer: { '@type': 'Answer', text: 'Fiber internet in Uganda starts at UGX 75,000/month for 25 Mbps with Zuku Fiber, going up to UGX 199,000 for 200 Mbps. All plans include free installation and a free router.' } },
          { '@type': 'Question', name: 'Which areas does Zuku Fiber cover?', acceptedAnswer: { '@type': 'Answer', text: 'Zuku Fiber covers Kololo, Ntinda, Naguru, Bugolobi, Muyenga, Kisaasi, Kyanja, Bukoto, Munyonyo, and the Entebbe Road corridor in Kampala.' } },
          { '@type': 'Question', name: 'How do I pay for internet in Uganda?', acceptedAnswer: { '@type': 'Answer', text: 'Pay via MTN MoMo, Airtel Money, bank transfer, or at walk-in agents across Kampala. No long-term contracts required.' } },
          { '@type': 'Question', name: 'Is Zuku Fiber better than MTN or Airtel?', acceptedAnswer: { '@type': 'Answer', text: 'Yes. Unlike MTN and Airtel which use mobile broadband with fair usage policies, Zuku Fiber uses dedicated fiber optic infrastructure with truly unlimited data and zero throttling.' } },
        ],
      },
    ],
  };

  return (
    <main className="min-h-screen bg-[#0a0f1e] text-gray-300 font-sans selection:bg-blue-500/30">

      {/* Hero */}
      <section className="relative w-full pt-32 pb-20 overflow-hidden bg-gradient-to-b from-blue-900/20 to-[#0a0f1e]">
        <div className="max-w-7xl mx-auto px-4 relative z-10 flex flex-col items-center text-center">
          <div className="inline-block bg-white/10 text-white text-sm tracking-wide uppercase rounded-full px-4 py-1.5 mb-6 border border-white/10 backdrop-blur-sm">
            🏆 Uganda&apos;s #1 Ranked Fiber ISP — 2026
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight max-w-5xl tracking-tight">
            Best Internet Providers in{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-blue-600">
              Uganda 2026
            </span>
            : Full Comparison
          </h1>
          <p className="text-xl md:text-2xl text-gray-200 mb-8 max-w-3xl">
            We compared every major ISP in Uganda — speeds, prices, data caps, and reliability. Here&apos;s who comes out on top and why Zuku Fiber is the best internet provider Uganda has for home and business.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 mb-12">
            <Link href="https://wa.me/2560775260196" className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-8 py-4 font-semibold transition-all duration-300 shadow-lg shadow-blue-600/20 text-lg">
              Get Connected via WhatsApp
            </Link>
            <Link href="/#plans" className="border border-white/20 text-white hover:bg-white/10 rounded-lg px-8 py-4 font-semibold transition-all duration-300 text-lg">
              View Plans &amp; Pricing
            </Link>
          </div>
          <div className="flex flex-wrap justify-center gap-3 text-sm font-medium text-white/90">
            {['⚡ Free Installation', '📡 Free Wi-Fi Router', '📺 100+ TV Channels', '🔒 No Contracts'].map(t => (
              <span key={t} className="flex items-center gap-2 bg-white/5 rounded-full px-4 py-2 border border-white/10">{t}</span>
            ))}
          </div>
        </div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-blue-600/10 rounded-full blur-[120px] -z-10 pointer-events-none" />
      </section>

      {/* Quick stats */}
      <section className="border-y border-white/5 bg-white/[0.02]">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center divide-x divide-white/10">
            {[
              { val: '99.9%', label: 'Uptime SLA' },
              { val: '5ms', label: 'Latency' },
              { val: '200 Mbps', label: 'Max Speed' },
              { val: '50,000+', label: 'Happy Homes' },
            ].map(s => (
              <div key={s.label} className="px-4">
                <div className="text-3xl font-bold text-white mb-1">{s.val}</div>
                <div className="text-xs uppercase tracking-wider text-gray-400">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why this matters */}
      <section className="py-24 max-w-7xl mx-auto px-4">
        <div className="max-w-4xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">How We Chose the Best Internet in Uganda</h2>
          <p className="text-lg text-gray-300 mb-6 leading-relaxed">
            Choosing the best internet provider Uganda wide comes down to four things: speed consistency, data policy, price, and support. Most ISPs in Uganda advertise impressive speeds but quietly apply fair usage policies, throttle connections during peak hours, or charge for installation. We tested every major provider across Kampala — Kololo, Ntinda, Naguru, Bugolobi, Muyenga, and Kisaasi — and the results were clear.
          </p>
          <p className="text-lg text-gray-300 leading-relaxed">
            The best fiber internet Uganda households deserve should work just as fast at 9 PM on a Friday as it does at 9 AM on a Tuesday. It should have no data caps, free installation, and a real person to call when something goes wrong. Only one provider in Uganda meets every one of these standards in 2026.
          </p>
        </div>

        {/* Feature grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { icon: '🚀', title: 'Zero Throttling — Guaranteed', body: 'Our 100 Mbps plan delivers 100 Mbps at 9 PM on a Friday. No artificial speed limits during peak hours. This is what true unlimited internet Uganda looks like.' },
            { icon: '⚖️', title: 'Symmetrical Fiber Speeds', body: 'Upload as fast as you download. Essential for remote workers, content creators, and video calls. The best internet for working from home Uganda provides.' },
            { icon: '📞', title: '24/7 Kampala-Based Support', body: 'Our engineers are based in Kampala — not overseas. Fast, local response every time. The kind of support that sets the best ISP Uganda apart from the rest.' },
            { icon: '💰', title: 'Honest, Flat-Rate Pricing', body: 'From UGX 75,000/month, you get a fixed speed forever — not a "up to" speed that halves during busy periods. True cheapest internet bundles Uganda offers for fiber.' },
            { icon: '🛡️', title: 'Built-In Network Security', body: 'DDoS protection and encrypted DNS at the network level. Every Kampala home on our network is protected by default.' },
            { icon: '📺', title: '100+ TV Channels Free', body: 'Every plan includes our full digital TV package — BBC, CNN, SuperSport, NTV Uganda, Disney, and 80+ more. No extra cost, ever.' },
          ].map(f => (
            <div key={f.title} className="bg-white/5 border border-white/10 rounded-2xl p-8 hover:bg-white/[0.08] transition-colors">
              <div className="text-4xl mb-4">{f.icon}</div>
              <h3 className="text-xl font-bold text-white mb-3">{f.title}</h3>
              <p className="text-gray-400 leading-relaxed">{f.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Comparison Table */}
      <section className="py-24 bg-black/40 border-y border-white/5">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16 max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Internet Providers Uganda Comparison 2026</h2>
            <p className="text-lg text-gray-400">
              The definitive Airtel vs MTN vs Zuku Uganda breakdown. We compare technology, pricing, data caps, throttling, and more so you can make an informed decision.
            </p>
          </div>
          <div className="w-full overflow-x-auto rounded-2xl border border-white/10 shadow-2xl bg-[#0a0f1e]">
            <table className="w-full text-left border-collapse min-w-[950px]">
              <thead>
                <tr className="bg-white/5 border-b border-white/10 text-white font-semibold text-sm uppercase tracking-wide">
                  <th className="p-5">Provider</th>
                  <th className="p-5">Technology</th>
                  <th className="p-5">Starting Price</th>
                  <th className="p-5">Max Speed</th>
                  <th className="p-5">Data Cap</th>
                  <th className="p-5">Throttling</th>
                  <th className="p-5">Free Install</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-gray-300">
                <tr className="bg-blue-600/10 hover:bg-blue-600/20 transition-colors border-l-4 border-blue-500">
                  <td className="p-5 font-bold text-white"><span className="text-blue-400">★ </span>Zuku Fiber</td>
                  <td className="p-5">Pure Fiber Optic</td>
                  <td className="p-5 text-white font-semibold">UGX 75,000/mo <span className="block text-xs text-blue-400 font-normal">Best Value</span></td>
                  <td className="p-5">200 Mbps</td>
                  <td className="p-5 text-green-400 font-semibold">None — Unlimited</td>
                  <td className="p-5 text-green-400 font-semibold">Never</td>
                  <td className="p-5">✅ Always free</td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="p-5 font-medium text-white">MTN Uganda (WakaNet)</td>
                  <td className="p-5">5G / Fiber</td>
                  <td className="p-5">UGX 130,000/mo</td>
                  <td className="p-5">Varies</td>
                  <td className="p-5 text-yellow-500">Fair Usage Policy</td>
                  <td className="p-5 text-red-400">Yes (peak hours)</td>
                  <td className="p-5">❌ Paid</td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="p-5 font-medium text-white">Airtel Uganda</td>
                  <td className="p-5">5G / Mobile Broadband</td>
                  <td className="p-5">UGX 150,000/mo</td>
                  <td className="p-5">Varies</td>
                  <td className="p-5 text-red-400">Volume Caps Apply</td>
                  <td className="p-5 text-red-400">Yes</td>
                  <td className="p-5">❌ Paid Router</td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="p-5 font-medium text-white">Roke Telkom</td>
                  <td className="p-5">Wireless / Fiber</td>
                  <td className="p-5">UGX 112,000/mo</td>
                  <td className="p-5">100 Mbps</td>
                  <td className="p-5 text-yellow-500">Time-based caps</td>
                  <td className="p-5 text-red-400">Yes</td>
                  <td className="p-5">❌ Usually paid</td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="p-5 font-medium text-white">Faibanet</td>
                  <td className="p-5">Fiber</td>
                  <td className="p-5">UGX 100,000/mo</td>
                  <td className="p-5">50 Mbps</td>
                  <td className="p-5 text-green-400">Unlimited</td>
                  <td className="p-5 text-yellow-500">Unclear</td>
                  <td className="p-5">❌ Often paid</td>
                </tr>
              </tbody>
            </table>
          </div>
          <p className="mt-6 text-center text-sm text-gray-500">
            * Based on standard residential plans as of early 2026. See our <Link href="/#plans" className="text-blue-400 hover:underline">detailed pricing</Link> for full Zuku Fiber Uganda plan breakdown.
          </p>
        </div>
      </section>

      {/* Plans */}
      <section className="py-24 max-w-7xl mx-auto px-4" id="plans">
        <div className="text-center mb-16">
          <div className="inline-block bg-blue-500/10 text-blue-400 text-sm tracking-wide uppercase rounded-full px-4 py-1.5 mb-4">
            Simple Pricing
          </div>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">Uganda&apos;s Best Value Fiber Plans</h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Every plan includes free installation, free router, and 100+ TV channels. No contracts, no surprises.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { speed: '25 Mbps', price: '75,000', desc: 'Solo users & browsing' },
            { speed: '50 Mbps', price: '89,400', desc: 'Families & streaming', popular: true },
            { speed: '100 Mbps', price: '110,000', desc: 'Power users & gaming' },
            { speed: '200 Mbps', price: '199,000', desc: 'Content creators' },
          ].map(plan => (
            <div key={plan.speed} className={`relative bg-white/5 border rounded-2xl p-8 flex flex-col hover:bg-white/[0.08] transition-all ${plan.popular ? 'border-blue-500 shadow-[0_0_30px_rgba(59,130,246,0.15)]' : 'border-white/10'}`}>
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-xs font-bold uppercase tracking-wider py-1.5 px-4 rounded-full">Most Popular</div>
              )}
              <h3 className="text-2xl font-bold text-white mb-1">{plan.speed}</h3>
              <p className="text-sm text-gray-400 mb-4">{plan.desc}</p>
              <div className="text-3xl font-extrabold text-white mb-6">
                <span className="text-base font-normal text-gray-400">UGX </span>{plan.price}
                <span className="text-sm font-normal text-gray-400 block mt-1">/ month</span>
              </div>
              <ul className="space-y-2 mb-8 flex-grow text-sm text-gray-300">
                {['Unlimited Data', 'Zero Throttling', 'Free Installation', 'Free Wi-Fi Router', '100+ TV Channels'].map(f => (
                  <li key={f} className="flex items-center gap-2">
                    <svg className="w-4 h-4 text-blue-500 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                    {f}
                  </li>
                ))}
              </ul>
              <Link href="https://wa.me/2560775260196" className={`w-full py-3 rounded-lg font-semibold text-center transition-colors text-sm ${plan.popular ? 'bg-blue-600 hover:bg-blue-700 text-white' : 'bg-white/10 hover:bg-white/20 text-white'}`}>
                Get {plan.speed}
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* Coverage */}
      <section className="py-24 bg-black/40 border-y border-white/5">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Coverage Across Kampala</h2>
            <p className="text-lg text-gray-400 max-w-2xl mx-auto">
              Zuku Fiber is expanding rapidly across Kampala. We currently serve the following areas with full fiber optic coverage:
            </p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {['Kololo', 'Ntinda', 'Naguru', 'Bugolobi', 'Muyenga', 'Kisaasi', 'Kyanja', 'Bukoto', 'Munyonyo', 'Entebbe Road', 'Nakasero', 'Kansanga'].map(area => (
              <div key={area} className="flex items-center gap-3 bg-white/5 border border-white/10 rounded-xl px-4 py-3">
                <span className="text-green-400 text-lg">✓</span>
                <span className="text-white font-medium">{area}</span>
              </div>
            ))}
          </div>
          <div className="mt-8 text-center">
            <p className="text-gray-400 mb-4">Not sure if we cover your area? WhatsApp us and we&apos;ll confirm instantly.</p>
            <Link href="https://wa.me/2560775260196" className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-6 py-3 font-semibold transition-colors inline-block">
              Check My Area
            </Link>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-24" id="faq">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">Frequently Asked Questions</h2>
            <p className="text-lg text-gray-400">Everything Ugandan households ask before choosing the best ISP Uganda wide.</p>
          </div>
          <div className="space-y-4">
            {[
              { q: 'Which internet is best in Uganda?', a: 'Zuku Fiber is the best internet in Uganda for home use, offering true unlimited fiber with no data caps, 99.9% uptime, and symmetrical speeds from UGX 75,000/month.' },
              { q: 'What is the cheapest internet in Uganda?', a: 'Zuku Fiber offers the cheapest unlimited fiber internet in Uganda starting at UGX 75,000/month for 25 Mbps — with free installation and no contracts.' },
              { q: 'Which ISP is fastest in Uganda?', a: 'Zuku Fiber delivers the fastest home internet Uganda offers, with symmetrical speeds up to 200 Mbps and just 5ms latency on a dedicated fiber optic network.' },
              { q: 'Does Zuku Fiber have data caps?', a: 'No. Zuku Fiber Uganda has strictly unlimited plans with zero data caps and no throttling at any time of day.' },
              { q: 'How much is fiber internet in Uganda?', a: 'Fiber internet in Uganda with Zuku starts at UGX 75,000 for 25 Mbps, going up to UGX 199,000 for 200 Mbps. All plans include free installation and a free router.' },
              { q: 'Which areas does Zuku Fiber cover?', a: 'Zuku Fiber covers Kololo, Ntinda, Naguru, Bugolobi, Muyenga, Kisaasi, Kyanja, Bukoto, Munyonyo, and the Entebbe Road corridor in Kampala.' },
              { q: 'How do I pay for internet in Uganda?', a: 'Pay via MTN MoMo, Airtel Money, bank transfer, or at walk-in agents across Kampala. No long-term contracts required.' },
              { q: 'Is Zuku Fiber better than MTN or Airtel?', a: 'Yes. Unlike MTN and Airtel which use mobile broadband with fair usage policies, Zuku Fiber uses dedicated fiber optic infrastructure with truly unlimited data and zero throttling.' },
            ].map(faq => (
              <details key={faq.q} className="group bg-white/5 border border-white/10 rounded-xl overflow-hidden [&_summary::-webkit-details-marker]:hidden">
                <summary className="flex items-center justify-between cursor-pointer p-6 font-semibold text-white hover:bg-white/[0.07] transition-colors">
                  <span className="text-base pr-4">{faq.q}</span>
                  <span className="transition group-open:rotate-180 bg-white/10 rounded-full p-1 text-gray-300">
                    <svg fill="none" height="20" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5" width="20"><path d="M6 9l6 6 6-6" /></svg>
                  </span>
                </summary>
                <div className="px-6 pb-6 pt-2 text-gray-400 text-base leading-relaxed border-t border-white/5">{faq.a}</div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative py-28 overflow-hidden bg-blue-900 border-t border-blue-500/20 text-center">
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0f1e] to-transparent opacity-80" />
        <div className="relative max-w-4xl mx-auto px-4 z-10">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Ready to switch to Uganda&apos;s best internet?</h2>
          <p className="text-xl text-blue-100 mb-10 max-w-2xl mx-auto">
            Join 50,000+ homes across Kampala enjoying the best unlimited internet Uganda 2026. Free install. No contracts. Same-day activation available.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="https://wa.me/2560775260196" className="bg-white text-blue-900 hover:bg-gray-100 rounded-lg px-8 py-4 font-bold shadow-xl text-lg transition-all hover:-translate-y-0.5">
              Sign Up via WhatsApp
            </Link>
            <Link href="/#features" className="border border-white/30 text-white hover:bg-white/10 rounded-lg px-8 py-4 font-semibold text-lg transition-all">
              Learn More
            </Link>
          </div>
        </div>
      </section>

      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
    </main>
  );
}
