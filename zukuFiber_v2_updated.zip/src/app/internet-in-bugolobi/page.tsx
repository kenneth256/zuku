import type { Metadata } from 'next';
import Link from 'next/link';

export function generateMetadata(): Metadata {
  return {
    title: 'Best Internet in Bugolobi Kampala 2026 | Zuku Fiber Uganda',
    description: 'Fastest fiber internet in Bugolobi Kampala. Zuku Fiber offers unlimited home internet from UGX 75,000/month — free installation, zero data caps. Get connected today.',
    keywords: ['internet in Bugolobi Kampala','best internet in Uganda','fiber internet Kampala','best WiFi in Kampala','unlimited internet Uganda','home internet Uganda','fastest internet Uganda','best fiber internet Uganda','best internet provider Uganda','cheapest internet bundles Uganda','internet providers Uganda comparison','best ISP Uganda','Zuku Fiber Uganda','best unlimited internet Uganda 2026','fiber internet Uganda price'],
    openGraph: { title: 'Best Internet in Bugolobi Kampala 2026 | Zuku Fiber Uganda', description: 'Zuku Fiber in Bugolobi — unlimited fiber from UGX 75,000/month. Free installation, free router, zero data caps.', url: 'https://zukufiberuganda.vercel.app/internet-in-bugolobi', siteName: 'Zuku Fiber Uganda' },
    alternates: { canonical: 'https://zukufiberuganda.vercel.app/internet-in-bugolobi' },
  };
}

export default function InternetInBugolobiPage() {
  const jsonLd = { '@context': 'https://schema.org', '@graph': [{ '@type': 'LocalBusiness', name: 'Zuku Fiber Uganda', url: 'https://zukufiberuganda.vercel.app/', telephone: '0775 260 196', address: { '@type': 'PostalAddress', streetAddress: 'Diamond Trust Building', addressLocality: 'Kampala', addressCountry: 'Uganda' }, geo: { '@type': 'GeoCoordinates', latitude: 0.3476, longitude: 32.5825 } }, { '@type': 'BreadcrumbList', itemListElement: [{ '@type': 'ListItem', position: 1, name: 'Home', item: 'https://zukufiberuganda.vercel.app/' }, { '@type': 'ListItem', position: 2, name: 'Internet in Bugolobi', item: 'https://zukufiberuganda.vercel.app/internet-in-bugolobi' }] }, { '@type': 'FAQPage', mainEntity: [{ '@type': 'Question', name: 'Which internet is best in Bugolobi?', acceptedAnswer: { '@type': 'Answer', text: 'Zuku Fiber is the best internet in Bugolobi, offering dedicated fiber with no data caps, zero throttling, and 99.9% uptime from UGX 75,000/month.' } }, { '@type': 'Question', name: 'Is Zuku Fiber available in Bugolobi?', acceptedAnswer: { '@type': 'Answer', text: 'Yes, Zuku Fiber is fully available in Bugolobi with same-day installation available in most parts of the area.' } }, { '@type': 'Question', name: 'How much is internet in Bugolobi?', acceptedAnswer: { '@type': 'Answer', text: 'Zuku Fiber in Bugolobi starts at UGX 75,000/month for 25 Mbps unlimited fiber with free installation and a free router.' } }, { '@type': 'Question', name: 'How do I get Zuku Fiber in Bugolobi?', acceptedAnswer: { '@type': 'Answer', text: 'WhatsApp 0775 260 196 or call. We will schedule a free installation at your home in Bugolobi. Most installs are completed within 24 hours.' } }, { '@type': 'Question', name: 'What is the fastest internet in Bugolobi?', acceptedAnswer: { '@type': 'Answer', text: 'Zuku Fiber delivers symmetrical speeds up to 200 Mbps with 5ms latency — the fastest home internet available in Bugolobi.' } }, { '@type': 'Question', name: 'Does Zuku throttle speeds in Bugolobi?', acceptedAnswer: { '@type': 'Answer', text: 'No. Zuku Fiber never throttles. Your speed stays constant 24/7 regardless of how busy the network is.' } }, { '@type': 'Question', name: 'What internet plan should I get in Bugolobi?', acceptedAnswer: { '@type': 'Answer', text: 'The 50 Mbps plan at UGX 89,400/month is ideal for most Bugolobi households. For remote workers or large families, the 100 Mbps plan is recommended.' } }, { '@type': 'Question', name: 'Can I pay with MTN MoMo in Bugolobi?', acceptedAnswer: { '@type': 'Answer', text: 'Yes. Zuku Fiber accepts MTN MoMo, Airtel Money, bank transfer, and walk-in agent payments.' } }] }] };

  return (
    <main className="min-h-screen bg-[#0a0f1e] text-gray-300 font-sans selection:bg-blue-500/30">
      <section className="relative w-full pt-32 pb-20 overflow-hidden bg-gradient-to-b from-blue-900/20 to-[#0a0f1e]">
        <div className="max-w-7xl mx-auto px-4 relative z-10 flex flex-col items-center text-center">
          <div className="inline-block bg-white/10 text-white text-sm tracking-wide uppercase rounded-full px-4 py-1.5 mb-6 border border-white/10 backdrop-blur-sm">
            📡 Now Live in Bugolobi, Kampala
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight max-w-5xl tracking-tight">
            The Fastest{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-blue-600">
              Internet in Bugolobi
            </span>{' '}
            Kampala
          </h1>
          <p className="text-xl text-gray-200 mb-8 max-w-3xl">
            Stop buffering. Get Bugolobi&apos;s best fiber internet delivered to your door. Unlimited data, zero throttling, free installation — from UGX 75,000/month.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 mb-12">
            <Link href="https://wa.me/2560775260196" className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-8 py-4 font-semibold transition-all shadow-lg shadow-blue-600/20 text-lg">
              Get Connected via WhatsApp
            </Link>
            <Link href="/#plans" className="border border-white/20 text-white hover:bg-white/10 rounded-lg px-8 py-4 font-semibold transition-all text-lg">
              View Pricing Plans
            </Link>
          </div>
          <div className="flex flex-wrap justify-center gap-3 text-sm font-medium text-white/90">
            {['⚡ Free Installation', '📡 Free Wi-Fi Router', '📺 100+ TV Channels', '🔒 No Contracts'].map(t => (
              <span key={t} className="flex items-center gap-2 bg-white/5 rounded-full px-4 py-2 border border-white/10">{t}</span>
            ))}
          </div>
        </div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-blue-600/10 rounded-full blur-[120px] -z-10 pointer-events-none" />
      </section>

      <section className="border-y border-white/5 bg-white/[0.02]">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center divide-x divide-white/10">
            {[{ val: '99.9%', label: 'Uptime Guarantee' }, { val: '200 Mbps', label: 'Max Speed' }, { val: '5ms', label: 'Latency' }, { val: 'Unlimited', label: 'No Data Caps' }].map(s => (
              <div key={s.label} className="px-4">
                <div className="text-2xl font-bold text-white mb-1">{s.val}</div>
                <div className="text-xs uppercase tracking-wider text-gray-400">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 max-w-7xl mx-auto px-4">
        <div className="text-center mb-16 max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Why Bugolobi Residents Choose Zuku Fiber</h2>
          <p className="text-gray-400 text-lg">Here&apos;s what makes us the best internet provider Uganda homes in Bugolobi trust.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { icon: '🚀', title: 'Zero Throttling, Ever', body: 'Your plan speed is what you get — at 9 PM on Friday in Bugolobi, just as at 9 AM on Monday. Internet without data cap Uganda, guaranteed.' },
            { icon: '⚖️', title: 'True Symmetrical Speeds', body: 'Upload as fast as you download. Perfect for Bugolobi remote workers, students, and families running multiple devices.' },
            { icon: '📞', title: '24/7 Kampala Support', body: 'Kampala-based engineers who know the network. Fast response, real people, every time.' },
          ].map(f => (
            <div key={f.title} className="bg-white/5 border border-white/10 rounded-2xl p-8 hover:bg-white/[0.08] transition-colors">
              <div className="text-4xl mb-4">{f.icon}</div>
              <h3 className="text-xl font-bold text-white mb-3">{f.title}</h3>
              <p className="text-gray-400 leading-relaxed">{f.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="py-16 bg-black/40 border-y border-white/5">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-white mb-10 text-center">Internet Providers in Bugolobi — Comparison</h2>
          <div className="w-full overflow-x-auto rounded-2xl border border-white/10 bg-[#0a0f1e]">
            <table className="w-full text-left border-collapse min-w-[750px]">
              <thead>
                <tr className="bg-white/5 border-b border-white/10 text-white font-semibold text-sm uppercase tracking-wide">
                  <th className="p-5">Provider</th><th className="p-5">Price</th><th className="p-5">Technology</th><th className="p-5">Data Cap</th><th className="p-5">Throttling</th><th className="p-5">Free Install</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                <tr className="bg-blue-600/10 border-l-4 border-blue-500">
                  <td className="p-5 font-bold text-white">★ Zuku Fiber</td><td className="p-5 text-white font-semibold">UGX 75,000/mo</td><td className="p-5">Pure Fiber</td><td className="p-5 text-green-400">None</td><td className="p-5 text-green-400">Never</td><td className="p-5">✅ Free</td>
                </tr>
                <tr className="hover:bg-white/5"><td className="p-5 text-white">MTN WakaNet</td><td className="p-5">UGX 130,000/mo</td><td className="p-5">5G/Fiber</td><td className="p-5 text-yellow-500">Fair Usage</td><td className="p-5 text-red-400">Yes</td><td className="p-5">❌ Paid</td></tr>
                <tr className="hover:bg-white/5"><td className="p-5 text-white">Airtel Uganda</td><td className="p-5">UGX 150,000/mo</td><td className="p-5">5G/4G</td><td className="p-5 text-red-400">Volume Caps</td><td className="p-5 text-red-400">Yes</td><td className="p-5">❌ Paid</td></tr>
                <tr className="hover:bg-white/5"><td className="p-5 text-white">Roke Telkom</td><td className="p-5">UGX 112,000/mo</td><td className="p-5">Wireless</td><td className="p-5 text-yellow-500">Time-based</td><td className="p-5 text-red-400">Yes</td><td className="p-5">❌ Usually paid</td></tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section className="py-24 max-w-7xl mx-auto px-4" id="plans">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-white mb-4">Plans Available in Bugolobi</h2>
          <p className="text-gray-400 max-w-xl mx-auto">Free installation, free router, 100+ TV channels included with every plan. No contracts.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[{ speed: '25 Mbps', price: '75,000', desc: 'Solo & browsing' }, { speed: '50 Mbps', price: '89,400', desc: 'Families & streaming', popular: true }, { speed: '100 Mbps', price: '110,000', desc: 'Remote work & gaming' }, { speed: '200 Mbps', price: '199,000', desc: 'Power users & offices' }].map(plan => (
            <div key={plan.speed} className={`relative bg-white/5 border rounded-2xl p-8 flex flex-col hover:bg-white/[0.08] transition-all ${('popular' in plan && plan.popular) ? 'border-blue-500 shadow-[0_0_30px_rgba(59,130,246,0.15)]' : 'border-white/10'}`}>
              {'popular' in plan && plan.popular && (<div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-xs font-bold uppercase tracking-wider py-1.5 px-4 rounded-full">Most Popular</div>)}
              <h3 className="text-2xl font-bold text-white mb-1">{plan.speed}</h3>
              <p className="text-sm text-gray-400 mb-4">{plan.desc}</p>
              <div className="text-3xl font-extrabold text-white mb-6"><span className="text-base font-normal text-gray-400">UGX </span>{plan.price}<span className="text-sm font-normal text-gray-400 block mt-1">/ month</span></div>
              <Link href="https://wa.me/2560775260196" className={`w-full py-3 rounded-lg font-semibold text-center transition-colors text-sm ${('popular' in plan && plan.popular) ? 'bg-blue-600 hover:bg-blue-700 text-white' : 'bg-white/10 hover:bg-white/20 text-white'}`}>Get {plan.speed}</Link>
            </div>
          ))}
        </div>
      </section>

      <section className="py-24 bg-black/40 border-t border-white/5">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-white mb-12 text-center">Bugolobi Internet FAQs</h2>
          <div className="space-y-4">
            {[
              { q: 'Which internet is best in Bugolobi?', a: 'Zuku Fiber is the best internet in Bugolobi, offering dedicated fiber with no data caps, zero throttling, and 99.9% uptime from UGX 75,000/month.' },
              { q: 'Is Zuku Fiber available in Bugolobi?', a: 'Yes, Zuku Fiber is fully available in Bugolobi with same-day installation in most parts of the area.' },
              { q: 'How much is internet in Bugolobi?', a: 'Zuku Fiber in Bugolobi starts at UGX 75,000/month for 25 Mbps unlimited fiber with free installation and a free router.' },
              { q: 'How do I get Zuku Fiber in Bugolobi?', a: 'WhatsApp 0775 260 196 or call. We schedule a free installation at your home. Most installs in Bugolobi are done within 24 hours.' },
              { q: 'What is the fastest internet in Bugolobi?', a: 'Zuku Fiber delivers up to 200 Mbps symmetrical speeds with 5ms latency — the fastest home internet in Bugolobi.' },
              { q: 'Does Zuku throttle speeds in Bugolobi?', a: 'No. Zuku Fiber never throttles. Your speed stays constant 24/7 regardless of the time of day.' },
              { q: 'What internet plan should I get in Bugolobi?', a: 'For most Bugolobi households, the 50 Mbps plan at UGX 89,400/month is ideal. For remote workers, the 100 Mbps plan is recommended.' },
              { q: 'Can I pay with MTN MoMo in Bugolobi?', a: 'Yes. Zuku Fiber accepts MTN MoMo, Airtel Money, bank transfer, and walk-in agent payments.' },
            ].map(faq => (
              <details key={faq.q} className="group bg-white/5 border border-white/10 rounded-xl overflow-hidden [&_summary::-webkit-details-marker]:hidden">
                <summary className="flex items-center justify-between cursor-pointer p-6 font-semibold text-white hover:bg-white/[0.07] transition-colors">
                  <span className="pr-4">{faq.q}</span>
                  <span className="transition group-open:rotate-180 bg-white/10 rounded-full p-1 shrink-0"><svg fill="none" height="20" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5" width="20"><path d="M6 9l6 6 6-6" /></svg></span>
                </summary>
                <div className="px-6 pb-6 pt-2 text-gray-400 leading-relaxed border-t border-white/5">{faq.a}</div>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className="relative py-28 overflow-hidden bg-blue-900 border-t border-blue-500/20 text-center">
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0f1e] to-transparent opacity-80" />
        <div className="relative max-w-4xl mx-auto px-4 z-10">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Get connected in Bugolobi today.</h2>
          <p className="text-xl text-blue-100 mb-10 max-w-2xl mx-auto">Free installation. Free router. Free TV. From UGX 75,000/month. Same-day activation available in Bugolobi.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="https://wa.me/2560775260196" className="bg-white text-blue-900 hover:bg-gray-100 rounded-lg px-8 py-4 font-bold shadow-xl text-lg transition-all hover:-translate-y-0.5">Sign Up via WhatsApp</Link>
            <Link href="tel:+2560775260196" className="border border-white/30 text-white hover:bg-white/10 rounded-lg px-8 py-4 font-semibold text-lg transition-all">Call 0775 260 196</Link>
          </div>
        </div>
      </section>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
    </main>
  );
}
