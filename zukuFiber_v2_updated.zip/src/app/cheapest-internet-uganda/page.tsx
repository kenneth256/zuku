import type { Metadata } from 'next';
import Link from 'next/link';

export function generateMetadata(): Metadata {
  return {
    title: 'Cheapest Internet Bundles Uganda 2026 | From UGX 75,000',
    description: 'Find the cheapest internet bundles in Uganda 2026. Zuku Fiber offers unlimited home fiber from just UGX 75,000/month — free installation, no data caps.',
    keywords: [
      'cheapest internet bundles Uganda',
      'cheapest internet Uganda',
      'affordable internet Uganda',
      'best internet in Uganda',
      'unlimited internet Uganda',
      'home internet Uganda',
      'fiber internet Uganda price',
      'internet without data cap Uganda',
      'best internet provider Uganda',
      'fiber internet Kampala',
      'best WiFi in Kampala',
      'internet providers Uganda comparison',
      'best unlimited internet Uganda 2026',
      'best ISP Uganda',
      'Zuku Fiber Uganda',
    ],
    openGraph: {
      title: 'Cheapest Internet Bundles Uganda 2026 | From UGX 75,000',
      description: 'Cheapest unlimited internet in Uganda. Zuku Fiber from UGX 75,000/month — free installation, free router, 100+ TV channels. No hidden fees.',
      url: 'https://zukufiberuganda.vercel.app/cheapest-internet-uganda',
      siteName: 'Zuku Fiber Uganda',
    },
    alternates: { canonical: 'https://zukufiberuganda.vercel.app/cheapest-internet-uganda' },
  };
}

export default function CheapestInternetUgandaPage() {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@graph': [
      {
        '@type': 'LocalBusiness',
        name: 'Zuku Fiber Uganda',
        url: 'https://zukufiberuganda.vercel.app/',
        telephone: '0775 260 196',
        address: { '@type': 'PostalAddress', streetAddress: 'Diamond Trust Building', addressLocality: 'Kampala', addressCountry: 'Uganda' },
        geo: { '@type': 'GeoCoordinates', latitude: 0.3476, longitude: 32.5825 },
      },
      {
        '@type': 'BreadcrumbList',
        itemListElement: [
          { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://zukufiberuganda.vercel.app/' },
          { '@type': 'ListItem', position: 2, name: 'Cheapest Internet Uganda', item: 'https://zukufiberuganda.vercel.app/cheapest-internet-uganda' },
        ],
      },
      {
        '@type': 'FAQPage',
        mainEntity: [
          { '@type': 'Question', name: 'What is the cheapest internet in Uganda?', acceptedAnswer: { '@type': 'Answer', text: 'Zuku Fiber offers the cheapest unlimited fiber internet in Uganda starting at UGX 75,000/month for a 25 Mbps connection with zero data throttling and free installation.' } },
          { '@type': 'Question', name: 'How much is internet per month in Uganda?', acceptedAnswer: { '@type': 'Answer', text: 'Fiber internet in Uganda starts at UGX 75,000/month with Zuku Fiber. This includes free installation, free Wi-Fi router, and 100+ TV channels at no extra cost.' } },
          { '@type': 'Question', name: 'Are there hidden costs with Zuku Fiber?', acceptedAnswer: { '@type': 'Answer', text: 'No. Zuku Fiber has no hidden fees. The monthly plan price is all you pay — installation, router, and TV channels are all included for free.' } },
          { '@type': 'Question', name: 'Is there truly unlimited internet in Uganda?', acceptedAnswer: { '@type': 'Answer', text: 'Yes. Zuku Fiber offers genuinely unlimited internet with no data caps and no throttling. Your speed remains constant 24 hours a day, 7 days a week.' } },
          { '@type': 'Question', name: 'Can I pay for internet monthly with no contract?', acceptedAnswer: { '@type': 'Answer', text: 'Yes. Zuku Fiber offers monthly plans with no long-term contracts. You can pay via MTN MoMo, Airtel Money, bank transfer, or walk-in agents.' } },
          { '@type': 'Question', name: 'Which areas in Kampala have the cheapest fiber internet?', acceptedAnswer: { '@type': 'Answer', text: 'Zuku Fiber is available at the same affordable rates across Kololo, Ntinda, Naguru, Bugolobi, Muyenga, Kisaasi, Kyanja, Bukoto, Munyonyo, and Entebbe Road.' } },
          { '@type': 'Question', name: 'Is Zuku cheaper than MTN or Airtel for home internet?', acceptedAnswer: { '@type': 'Answer', text: 'Yes, when you factor in the true cost. MTN and Airtel charge extra for installation and routers, and apply data caps that force you to buy top-up bundles. Zuku Fiber at UGX 75,000/month is genuinely all-inclusive.' } },
          { '@type': 'Question', name: 'Can I get internet for UGX 75,000 in Uganda?', acceptedAnswer: { '@type': 'Answer', text: 'Yes. Zuku Fiber\'s entry-level plan is UGX 75,000/month for 25 Mbps unlimited fiber with free installation and free router — available across Kampala.' } },
        ],
      },
    ],
  };

  return (
    <main className="min-h-screen bg-[#0a0f1e] text-gray-300 font-sans selection:bg-blue-500/30">

      <section className="relative w-full pt-32 pb-20 overflow-hidden bg-gradient-to-b from-green-900/20 to-[#0a0f1e]">
        <div className="max-w-7xl mx-auto px-4 relative z-10 flex flex-col items-center text-center">
          <div className="inline-block bg-white/10 text-white text-sm tracking-wide uppercase rounded-full px-4 py-1.5 mb-6 border border-white/10 backdrop-blur-sm">
            💰 Uganda&apos;s Most Affordable Unlimited Fiber
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight max-w-5xl tracking-tight">
            Cheapest Internet Bundles{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-blue-500">Uganda 2026</span>
          </h1>
          <p className="text-xl text-gray-200 mb-4 max-w-3xl">
            Unlimited fiber internet from just <strong className="text-white">UGX 75,000/month</strong>. Free installation. Free router. Free TV. Zero data caps. No contracts.
          </p>
          <p className="text-base text-gray-400 mb-8 max-w-2xl">
            We break down every major internet provider in Uganda so you can see exactly which gives you the most value for your money — without the fine print surprises.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 mb-12">
            <Link href="https://wa.me/2560775260196" className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-8 py-4 font-semibold transition-all shadow-lg shadow-blue-600/20 text-lg">
              Get the Cheapest Plan
            </Link>
            <Link href="/#plans" className="border border-white/20 text-white hover:bg-white/10 rounded-lg px-8 py-4 font-semibold transition-all text-lg">
              Compare All Plans
            </Link>
          </div>
        </div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-green-600/10 rounded-full blur-[120px] -z-10 pointer-events-none" />
      </section>

      {/* Real cost breakdown */}
      <section className="py-24 max-w-7xl mx-auto px-4">
        <div className="text-center mb-16 max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">The Real Cost of Internet in Uganda</h2>
          <p className="text-gray-400 text-lg">Monthly price alone doesn&apos;t tell the full story. Here&apos;s what you actually pay with each provider.</p>
        </div>
        <div className="w-full overflow-x-auto rounded-2xl border border-white/10 bg-[#0a0f1e]">
          <table className="w-full text-left border-collapse min-w-[800px]">
            <thead>
              <tr className="bg-white/5 border-b border-white/10 text-white font-semibold text-sm uppercase tracking-wide">
                <th className="p-5">Provider</th>
                <th className="p-5">Monthly Fee</th>
                <th className="p-5">Installation</th>
                <th className="p-5">Router</th>
                <th className="p-5">Data Caps</th>
                <th className="p-5">Top-Up Cost</th>
                <th className="p-5">True Monthly Cost</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              <tr className="bg-blue-600/10 border-l-4 border-blue-500">
                <td className="p-5 font-bold text-white">★ Zuku Fiber</td>
                <td className="p-5 text-white font-semibold">UGX 75,000</td>
                <td className="p-5 text-green-400">Free</td>
                <td className="p-5 text-green-400">Free</td>
                <td className="p-5 text-green-400">None</td>
                <td className="p-5 text-green-400">UGX 0</td>
                <td className="p-5 font-bold text-white">~UGX 75,000</td>
              </tr>
              <tr className="hover:bg-white/5 transition-colors">
                <td className="p-5 font-medium text-white">MTN WakaNet</td>
                <td className="p-5">UGX 130,000</td>
                <td className="p-5 text-red-400">~UGX 50,000</td>
                <td className="p-5 text-red-400">~UGX 80,000</td>
                <td className="p-5 text-yellow-500">Fair Usage</td>
                <td className="p-5 text-yellow-500">Varies</td>
                <td className="p-5 text-yellow-500">UGX 130,000+</td>
              </tr>
              <tr className="hover:bg-white/5 transition-colors">
                <td className="p-5 font-medium text-white">Airtel Uganda</td>
                <td className="p-5">UGX 150,000</td>
                <td className="p-5 text-red-400">~UGX 50,000</td>
                <td className="p-5 text-red-400">~UGX 80,000</td>
                <td className="p-5 text-red-400">Volume Caps</td>
                <td className="p-5 text-red-400">Frequent</td>
                <td className="p-5 text-red-400">UGX 150,000+</td>
              </tr>
              <tr className="hover:bg-white/5 transition-colors">
                <td className="p-5 font-medium text-white">Roke Telkom</td>
                <td className="p-5">UGX 112,000</td>
                <td className="p-5 text-yellow-500">Usually paid</td>
                <td className="p-5 text-yellow-500">Varies</td>
                <td className="p-5 text-yellow-500">Time-based</td>
                <td className="p-5 text-yellow-500">Occasional</td>
                <td className="p-5 text-yellow-500">UGX 112,000+</td>
              </tr>
            </tbody>
          </table>
        </div>
        <p className="mt-6 text-center text-sm text-gray-500">First-year costs include installation amortised over 12 months. Zuku Fiber remains the cheapest internet bundles Uganda offers for true unlimited use.</p>
      </section>

      {/* What's included */}
      <section className="py-16 bg-black/40 border-y border-white/5">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">What&apos;s Included in Every Zuku Plan</h2>
          <p className="text-gray-400 mb-12 max-w-2xl mx-auto">No hidden costs. No upgrade fees. These are standard inclusions in every single plan.</p>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
            {[
              { icon: '⚡', label: 'Free Installation' },
              { icon: '📡', label: 'Free Wi-Fi Router' },
              { icon: '📺', label: '100+ TV Channels' },
              { icon: '🔒', label: 'No Contracts' },
              { icon: '♾️', label: 'Unlimited Data' },
              { icon: '🛡️', label: 'DDoS Protection' },
            ].map(item => (
              <div key={item.label} className="bg-white/5 border border-white/10 rounded-xl p-4 flex flex-col items-center gap-2">
                <span className="text-3xl">{item.icon}</span>
                <span className="text-white text-sm font-medium text-center">{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Plans */}
      <section className="py-24 max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">All Plans — No Hidden Fees</h2>
          <p className="text-gray-400 max-w-xl mx-auto">Choose your speed. Everything else is included. These are the cheapest internet bundles Uganda has for genuine unlimited fiber.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { speed: '25 Mbps', price: '75,000', desc: 'Solo users & browsing' },
            { speed: '50 Mbps', price: '89,400', desc: 'Families & HD streaming', popular: true },
            { speed: '100 Mbps', price: '110,000', desc: 'Gamers & smart homes' },
            { speed: '200 Mbps', price: '199,000', desc: 'Content creators' },
          ].map(plan => (
            <div key={plan.speed} className={`relative bg-white/5 border rounded-2xl p-8 flex flex-col hover:bg-white/[0.08] transition-all ${'popular' in plan && plan.popular ? 'border-blue-500 shadow-[0_0_30px_rgba(59,130,246,0.15)]' : 'border-white/10'}`}>
              {'popular' in plan && plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-xs font-bold uppercase tracking-wider py-1.5 px-4 rounded-full">Most Popular</div>
              )}
              <h3 className="text-2xl font-bold text-white mb-1">{plan.speed}</h3>
              <p className="text-sm text-gray-400 mb-4">{plan.desc}</p>
              <div className="text-3xl font-extrabold text-white mb-6">
                <span className="text-base font-normal text-gray-400">UGX </span>{plan.price}
                <span className="text-sm font-normal text-gray-400 block mt-1">/ month</span>
              </div>
              <ul className="space-y-2 mb-8 flex-grow text-sm text-gray-300">
                {['Free Installation', 'Free Wi-Fi Router', '100+ TV Channels', 'Unlimited Data', 'Zero Throttling'].map(f => (
                  <li key={f} className="flex items-center gap-2">
                    <svg className="w-4 h-4 text-green-500 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                    {f}
                  </li>
                ))}
              </ul>
              <Link href="https://wa.me/2560775260196" className={`w-full py-3 rounded-lg font-semibold text-center transition-colors text-sm ${'popular' in plan && plan.popular ? 'bg-blue-600 hover:bg-blue-700 text-white' : 'bg-white/10 hover:bg-white/20 text-white'}`}>
                Get This Plan
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="py-24 bg-black/40 border-t border-white/5">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-white mb-4">Pricing FAQs</h2>
            <p className="text-gray-400">Common questions about internet costs in Uganda.</p>
          </div>
          <div className="space-y-4">
            {[
              { q: 'What is the cheapest internet in Uganda?', a: 'Zuku Fiber offers the cheapest unlimited fiber internet in Uganda starting at UGX 75,000/month for a 25 Mbps connection with zero data throttling and free installation.' },
              { q: 'How much is internet per month in Uganda?', a: 'Fiber internet in Uganda starts at UGX 75,000/month with Zuku Fiber. This includes free installation, free Wi-Fi router, and 100+ TV channels at no extra cost.' },
              { q: 'Are there hidden costs with Zuku Fiber?', a: 'No. Zuku Fiber has no hidden fees. The monthly plan price is all you pay — installation, router, and TV channels are all included for free.' },
              { q: 'Is there truly unlimited internet in Uganda?', a: 'Yes. Zuku Fiber offers genuinely unlimited internet with no data caps and no throttling. Your speed remains constant 24/7.' },
              { q: 'Can I pay for internet monthly with no contract?', a: 'Yes. Zuku Fiber offers monthly plans with no long-term contracts. Pay via MTN MoMo, Airtel Money, bank transfer, or walk-in agents.' },
              { q: 'Which areas in Kampala have the cheapest fiber internet?', a: 'Zuku Fiber is available at the same affordable rates across Kololo, Ntinda, Naguru, Bugolobi, Muyenga, Kisaasi, Kyanja, Bukoto, Munyonyo, and Entebbe Road.' },
              { q: 'Is Zuku cheaper than MTN or Airtel for home internet?', a: 'Yes, when you factor in the true cost. MTN and Airtel charge extra for installation and routers, and apply data caps that force top-up bundles. Zuku Fiber at UGX 75,000/month is all-inclusive.' },
              { q: 'Can I get internet for UGX 75,000 in Uganda?', a: 'Yes. Zuku Fiber\'s entry-level plan is UGX 75,000/month for 25 Mbps unlimited fiber with free installation and free router — available across Kampala.' },
            ].map(faq => (
              <details key={faq.q} className="group bg-white/5 border border-white/10 rounded-xl overflow-hidden [&_summary::-webkit-details-marker]:hidden">
                <summary className="flex items-center justify-between cursor-pointer p-6 font-semibold text-white hover:bg-white/[0.07] transition-colors">
                  <span className="pr-4">{faq.q}</span>
                  <span className="transition group-open:rotate-180 bg-white/10 rounded-full p-1 shrink-0">
                    <svg fill="none" height="20" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5" width="20"><path d="M6 9l6 6 6-6" /></svg>
                  </span>
                </summary>
                <div className="px-6 pb-6 pt-2 text-gray-400 leading-relaxed border-t border-white/5">{faq.a}</div>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className="relative py-28 overflow-hidden bg-blue-900 border-t border-blue-500/20 text-center">
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0f1e] to-transparent opacity-80" />
        <div className="relative max-w-4xl mx-auto px-4 z-10">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Start with Uganda&apos;s most affordable fiber today</h2>
          <p className="text-xl text-blue-100 mb-10 max-w-2xl mx-auto">
            UGX 75,000/month. Free installation. No contracts. Same-day activation available across Kololo, Ntinda, Naguru, Bugolobi, and more.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="https://wa.me/2560775260196" className="bg-white text-blue-900 hover:bg-gray-100 rounded-lg px-8 py-4 font-bold shadow-xl text-lg transition-all hover:-translate-y-0.5">Sign Up via WhatsApp</Link>
            <Link href="tel:+2560775260196" className="border border-white/30 text-white hover:bg-white/10 rounded-lg px-8 py-4 font-semibold text-lg transition-all">Call 0775 260 196</Link>
          </div>
        </div>
      </section>

      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
    </main>
  );
}
