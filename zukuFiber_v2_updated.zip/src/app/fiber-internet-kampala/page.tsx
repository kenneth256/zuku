import type { Metadata } from 'next';
import Link from 'next/link';

export function generateMetadata(): Metadata {
  return {
    title: 'Fiber Internet Kampala 2026 | Zuku Fiber Uganda',
    description: 'Best fiber internet in Kampala 2026. Zuku Fiber delivers unlimited symmetrical speeds from UGX 75,000/month. Free installation across Kololo, Ntinda, Naguru & more.',
    keywords: ['fiber internet Kampala','best internet in Uganda','fiber internet Uganda','best WiFi in Kampala','home internet Uganda','unlimited internet Uganda','fastest internet Uganda','best fiber internet Uganda','internet in Kampala','best ISP Uganda','Zuku Fiber Uganda','cheapest internet bundles Uganda','internet providers Uganda comparison','best unlimited internet Uganda 2026','fiber internet Uganda price'],
    openGraph: { title: 'Fiber Internet Kampala 2026 | Zuku Fiber Uganda', description: 'Zuku Fiber — Kampala\'s fastest unlimited fiber internet from UGX 75,000/month. Free installation. Available in Kololo, Ntinda, Naguru, Bugolobi & more.', url: 'https://zukufiberuganda.vercel.app/fiber-internet-kampala', siteName: 'Zuku Fiber Uganda' },
    alternates: { canonical: 'https://zukufiberuganda.vercel.app/fiber-internet-kampala' },
  };
}

export default function FiberInternetKampalaPage() {
  const jsonLd = { '@context': 'https://schema.org', '@graph': [{ '@type': 'LocalBusiness', name: 'Zuku Fiber Uganda', url: 'https://zukufiberuganda.vercel.app/', telephone: '0775 260 196', address: { '@type': 'PostalAddress', streetAddress: 'Diamond Trust Building', addressLocality: 'Kampala', addressCountry: 'Uganda' }, geo: { '@type': 'GeoCoordinates', latitude: 0.3476, longitude: 32.5825 } }, { '@type': 'BreadcrumbList', itemListElement: [{ '@type': 'ListItem', position: 1, name: 'Home', item: 'https://zukufiberuganda.vercel.app/' }, { '@type': 'ListItem', position: 2, name: 'Fiber Internet Kampala', item: 'https://zukufiberuganda.vercel.app/fiber-internet-kampala' }] }, { '@type': 'FAQPage', mainEntity: [{ '@type': 'Question', name: 'Is fiber internet available in Kampala?', acceptedAnswer: { '@type': 'Answer', text: 'Yes. Zuku Fiber provides fiber optic internet across major Kampala areas including Kololo, Ntinda, Naguru, Bugolobi, Muyenga, Kisaasi, Kyanja, Bukoto, Munyonyo, and the Entebbe Road corridor.' } }, { '@type': 'Question', name: 'What is the fastest internet speed in Kampala?', acceptedAnswer: { '@type': 'Answer', text: 'Zuku Fiber offers the fastest home internet in Kampala with symmetrical speeds up to 200 Mbps and 5ms latency on a dedicated fiber optic network.' } }, { '@type': 'Question', name: 'How much is fiber internet in Kampala?', acceptedAnswer: { '@type': 'Answer', text: 'Fiber internet in Kampala with Zuku starts at UGX 75,000/month for 25 Mbps. All plans include free installation and a free router.' } }, { '@type': 'Question', name: 'Which areas of Kampala have fiber internet?', acceptedAnswer: { '@type': 'Answer', text: 'Zuku Fiber covers Kololo, Ntinda, Naguru, Bugolobi, Muyenga, Kisaasi, Kyanja, Bukoto, Munyonyo, and the Entebbe Road corridor.' } }, { '@type': 'Question', name: 'Is fiber better than MTN or Airtel in Kampala?', acceptedAnswer: { '@type': 'Answer', text: 'Yes. Dedicated fiber optic does not share bandwidth with mobile users, so speeds remain consistent at all hours. MTN and Airtel slow down during peak evening hours in Kampala.' } }, { '@type': 'Question', name: 'How long does fiber installation take in Kampala?', acceptedAnswer: { '@type': 'Answer', text: 'Most Zuku Fiber installations across Kampala are completed in 2–4 hours. Same-day connections are available in many areas.' } }, { '@type': 'Question', name: 'Does fiber internet in Kampala have data caps?', acceptedAnswer: { '@type': 'Answer', text: 'Not with Zuku Fiber. All plans are truly unlimited with no data caps and no throttling.' } }, { '@type': 'Question', name: 'Can I pay for fiber internet in Kampala with MTN MoMo?', acceptedAnswer: { '@type': 'Answer', text: 'Yes. Zuku Fiber accepts MTN MoMo, Airtel Money, bank transfer, and walk-in agent payments at locations across Kampala.' } }] }] };

  const areas = [
    { name: 'Kololo', desc: 'Full fiber coverage across the Kololo hill residential area.' },
    { name: 'Ntinda', desc: 'Live fiber network serving Ntinda estates and businesses.' },
    { name: 'Naguru', desc: 'Fiber optic coverage across Naguru including Naguru Estate.' },
    { name: 'Bugolobi', desc: 'Bugolobi flats and surrounding commercial areas fully covered.' },
    { name: 'Muyenga', desc: 'Covering Muyenga hill and Tank Hill Road corridor.' },
    { name: 'Kisaasi', desc: 'Full residential coverage in Kisaasi and surrounding areas.' },
    { name: 'Kyanja', desc: 'Expanding fiber coverage across Kyanja estate.' },
    { name: 'Bukoto', desc: 'Bukoto residential and commercial zones fully served.' },
    { name: 'Munyonyo', desc: 'Munyonyo lakeside residential coverage.' },
    { name: 'Entebbe Road', desc: 'Full corridor coverage from Kampala to Entebbe.' },
    { name: 'Nakasero', desc: 'Nakasero central business district and residences.' },
    { name: 'Kansanga', desc: 'Kansanga and Ggaba Road residential coverage.' },
  ];

  return (
    <main className="min-h-screen bg-[#0a0f1e] text-gray-300 font-sans selection:bg-blue-500/30">
      <section className="relative w-full pt-32 pb-20 overflow-hidden bg-gradient-to-b from-blue-900/20 to-[#0a0f1e]">
        <div className="max-w-7xl mx-auto px-4 relative z-10 flex flex-col items-center text-center">
          <div className="inline-block bg-white/10 text-white text-sm tracking-wide uppercase rounded-full px-4 py-1.5 mb-6 border border-white/10 backdrop-blur-sm">📡 Now Expanding Across Kampala</div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight max-w-5xl tracking-tight">
            Fiber Internet <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-blue-600">Kampala</span> — Fast, Unlimited &amp; Affordable
          </h1>
          <p className="text-xl text-gray-200 mb-8 max-w-3xl">Zuku Fiber brings dedicated fiber optic internet to your Kampala home. No shared wireless, no peak-hour slowdowns — just the best WiFi in Kampala from UGX 75,000/month.</p>
          <div className="flex flex-col sm:flex-row gap-4 mb-12">
            <Link href="https://wa.me/2560775260196" className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-8 py-4 font-semibold transition-all shadow-lg shadow-blue-600/20 text-lg">Check Coverage in My Area</Link>
            <Link href="/#plans" className="border border-white/20 text-white hover:bg-white/10 rounded-lg px-8 py-4 font-semibold transition-all text-lg">View Plans &amp; Prices</Link>
          </div>
        </div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-blue-600/10 rounded-full blur-[120px] -z-10 pointer-events-none" />
      </section>

      <section className="border-y border-white/5 bg-white/[0.02]">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center divide-x divide-white/10">
            {[{ val: 'Fiber Optic', label: 'Technology' }, { val: '200 Mbps', label: 'Max Speed' }, { val: '5ms', label: 'Latency' }, { val: 'Unlimited', label: 'Data Policy' }].map(s => (
              <div key={s.label} className="px-4"><div className="text-2xl font-bold text-white mb-1">{s.val}</div><div className="text-xs uppercase tracking-wider text-gray-400">{s.label}</div></div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 max-w-7xl mx-auto px-4">
        <div className="text-center mb-16 max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Why Fiber Beats Everything Else in Kampala</h2>
          <p className="text-gray-400 text-lg">Wireless broadband is shared infrastructure. Fiber optic goes directly to your door — a private, dedicated connection that doesn&apos;t slow down at 8 PM.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { icon: '🔌', title: 'Dedicated Connection', body: 'Your fiber cable runs directly to your home from our network node. You don\'t share bandwidth with your neighbours — ever. This is why fiber internet Kampala users experience consistent speeds 24/7.' },
            { icon: '⬆️', title: 'Symmetrical Upload Speeds', body: 'Fiber optic delivers equal upload and download speeds. On a 100 Mbps Zuku plan, you get 100 Mbps upload too. Wireless broadband typically gives you 10–20% of that for uploads.' },
            { icon: '📶', title: 'Stable in Bad Weather', body: 'Wireless signals degrade in heavy rain — Kampala\'s weather makes this a real problem. Fiber optic cables are unaffected by rain, lightning, or electromagnetic interference.' },
          ].map(f => (
            <div key={f.title} className="bg-white/5 border border-white/10 rounded-2xl p-8 hover:bg-white/[0.08] transition-colors">
              <div className="text-4xl mb-4">{f.icon}</div>
              <h3 className="text-xl font-bold text-white mb-3">{f.title}</h3>
              <p className="text-gray-400 leading-relaxed">{f.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="py-24 bg-black/40 border-y border-white/5">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Fiber Internet Coverage Across Kampala</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">We are live and expanding. Here are the areas currently served by Zuku Fiber in Kampala. WhatsApp us to confirm availability at your address.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {areas.map(area => (
              <div key={area.name} className="bg-white/5 border border-white/10 rounded-xl p-5 hover:bg-white/[0.08] transition-colors">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-green-400">●</span>
                  <span className="font-bold text-white">{area.name}</span>
                </div>
                <p className="text-sm text-gray-400 leading-relaxed">{area.desc}</p>
              </div>
            ))}
          </div>
          <div className="mt-10 text-center">
            <p className="text-gray-400 mb-4">Not on the list? We may still cover your area — or be expanding there soon.</p>
            <Link href="https://wa.me/2560775260196" className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-6 py-3 font-semibold transition-colors inline-block">Check My Address</Link>
          </div>
        </div>
      </section>

      <section className="py-24 max-w-7xl mx-auto px-4" id="plans">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Fiber Internet Kampala — Pricing</h2>
          <p className="text-gray-400 max-w-xl mx-auto">All plans include free installation, free Wi-Fi router, and 100+ TV channels. No contracts, no hidden fees.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[{ speed: '25 Mbps', price: '75,000', desc: 'Solo & browsing' }, { speed: '50 Mbps', price: '89,400', desc: 'Families & streaming', popular: true }, { speed: '100 Mbps', price: '110,000', desc: 'Gamers & power users' }, { speed: '200 Mbps', price: '199,000', desc: 'Creators & offices' }].map(plan => (
            <div key={plan.speed} className={`relative bg-white/5 border rounded-2xl p-8 flex flex-col hover:bg-white/[0.08] transition-all ${'popular' in plan && plan.popular ? 'border-blue-500 shadow-[0_0_30px_rgba(59,130,246,0.15)]' : 'border-white/10'}`}>
              {'popular' in plan && plan.popular && (<div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-xs font-bold uppercase tracking-wider py-1.5 px-4 rounded-full">Most Popular</div>)}
              <h3 className="text-2xl font-bold text-white mb-1">{plan.speed}</h3>
              <p className="text-sm text-gray-400 mb-4">{plan.desc}</p>
              <div className="text-3xl font-extrabold text-white mb-6"><span className="text-base font-normal text-gray-400">UGX </span>{plan.price}<span className="text-sm font-normal text-gray-400 block mt-1">/ month</span></div>
              <Link href="https://wa.me/2560775260196" className={`w-full py-3 rounded-lg font-semibold text-center transition-colors text-sm ${'popular' in plan && plan.popular ? 'bg-blue-600 hover:bg-blue-700 text-white' : 'bg-white/10 hover:bg-white/20 text-white'}`}>Get {plan.speed}</Link>
            </div>
          ))}
        </div>
      </section>

      <section className="py-24 bg-black/40 border-t border-white/5">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-white mb-12 text-center">Fiber Internet Kampala FAQs</h2>
          <div className="space-y-4">
            {[
              { q: 'Is fiber internet available in Kampala?', a: 'Yes. Zuku Fiber provides fiber optic internet across Kololo, Ntinda, Naguru, Bugolobi, Muyenga, Kisaasi, Kyanja, Bukoto, Munyonyo, and the Entebbe Road corridor.' },
              { q: 'What is the fastest internet speed in Kampala?', a: 'Zuku Fiber offers the fastest home internet in Kampala with symmetrical speeds up to 200 Mbps and 5ms latency on a dedicated fiber optic network.' },
              { q: 'How much is fiber internet in Kampala?', a: 'Fiber internet in Kampala with Zuku starts at UGX 75,000/month for 25 Mbps. All plans include free installation and a free router.' },
              { q: 'Which areas of Kampala have fiber internet?', a: 'Zuku Fiber covers Kololo, Ntinda, Naguru, Bugolobi, Muyenga, Kisaasi, Kyanja, Bukoto, Munyonyo, and the Entebbe Road corridor.' },
              { q: 'Is fiber better than MTN or Airtel in Kampala?', a: 'Yes. Dedicated fiber optic does not share bandwidth with mobile users, so speeds remain consistent at all hours. MTN and Airtel slow down during peak evening hours in Kampala.' },
              { q: 'How long does fiber installation take in Kampala?', a: 'Most Zuku Fiber installations across Kampala are completed in 2–4 hours. Same-day connections are available in many areas.' },
              { q: 'Does fiber internet in Kampala have data caps?', a: 'Not with Zuku Fiber. All plans are truly unlimited with no data caps and no throttling.' },
              { q: 'Can I pay for fiber internet in Kampala with MTN MoMo?', a: 'Yes. Zuku Fiber accepts MTN MoMo, Airtel Money, bank transfer, and walk-in agent payments at locations across Kampala.' },
            ].map(faq => (
              <details key={faq.q} className="group bg-white/5 border border-white/10 rounded-xl overflow-hidden [&_summary::-webkit-details-marker]:hidden">
                <summary className="flex items-center justify-between cursor-pointer p-6 font-semibold text-white hover:bg-white/[0.07] transition-colors">
                  <span className="pr-4">{faq.q}</span>
                  <span className="transition group-open:rotate-180 bg-white/10 rounded-full p-1 shrink-0"><svg fill="none" height="20" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5" width="20"><path d="M6 9l6 6 6-6" /></svg></span>
                </summary>
                <div className="px-6 pb-6 pt-2 text-gray-400 leading-relaxed border-t border-white/5">{faq.a}</div>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className="relative py-28 overflow-hidden bg-blue-900 border-t border-blue-500/20 text-center">
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0f1e] to-transparent opacity-80" />
        <div className="relative max-w-4xl mx-auto px-4 z-10">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Bring fiber to your Kampala home today.</h2>
          <p className="text-xl text-blue-100 mb-10 max-w-2xl mx-auto">Free installation. Free router. Free TV. From UGX 75,000/month. Same-day activation available across Kampala.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="https://wa.me/2560775260196" className="bg-white text-blue-900 hover:bg-gray-100 rounded-lg px-8 py-4 font-bold shadow-xl text-lg transition-all hover:-translate-y-0.5">Sign Up via WhatsApp</Link>
            <Link href="tel:+2560775260196" className="border border-white/30 text-white hover:bg-white/10 rounded-lg px-8 py-4 font-semibold text-lg transition-all">Call 0775 260 196</Link>
          </div>
        </div>
      </section>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
    </main>
  );
}
