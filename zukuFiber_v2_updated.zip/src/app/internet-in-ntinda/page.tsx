import type { Metadata } from 'next';
import Link from 'next/link';

export function generateMetadata(): Metadata {
  return {
    title: 'Best Internet in Ntinda Kampala 2026 | Zuku Fiber Uganda',
    description: 'Looking for the fastest internet in Ntinda Kampala? Zuku Fiber offers unlimited internet from just UGX 75,000/month with zero data caps. Get connected today!',
    keywords: [
      'internet in Ntinda Kampala',
      'best internet in Uganda',
      'best internet provider Uganda',
      'fastest internet Uganda',
      'best fiber internet Uganda',
      'unlimited internet Uganda',
      'best WiFi in Kampala',
      'cheapest internet bundles Uganda',
      'home internet Uganda',
      'fiber internet Kampala',
      'internet providers Uganda comparison',
      'best internet for working from home Uganda',
      'Airtel vs MTN vs Zuku Uganda',
      'best unlimited internet Uganda 2026',
      'internet in Kampala',
      'best ISP Uganda',
      'Zuku Fiber Uganda',
      'fiber internet Uganda price',
      'internet without data cap Uganda'
    ],
    openGraph: {
      title: 'Best Internet in Ntinda Kampala 2026 | Zuku Fiber Uganda',
      description: 'Looking for the fastest internet in Ntinda Kampala? Zuku Fiber offers unlimited internet from just UGX 75,000/month with zero data caps.',
      url: 'https://zukufiberuganda.vercel.app/internet-in-ntinda',
      siteName: 'Zuku Fiber Uganda',
    },
    alternates: {
      canonical: 'https://zukufiberuganda.vercel.app/internet-in-ntinda',
    },
  };
}

export default function InternetInNtindaPage() {
  const jsonLd = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "LocalBusiness",
        "name": "Zuku Fiber Uganda",
        "url": "https://zukufiberuganda.vercel.app/",
        "telephone": "0775 260 196",
        "address": {
          "@type": "PostalAddress",
          "streetAddress": "Diamond Trust Building",
          "addressLocality": "Kampala",
          "addressCountry": "Uganda"
        },
        "geo": {
          "@type": "GeoCoordinates",
          "latitude": 0.3476,
          "longitude": 32.5825
        }
      },
      {
        "@type": "BreadcrumbList",
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "name": "Home",
            "item": "https://zukufiberuganda.vercel.app/"
          },
          {
            "@type": "ListItem",
            "position": 2,
            "name": "Internet in Ntinda",
            "item": "https://zukufiberuganda.vercel.app/internet-in-ntinda"
          }
        ]
      },
      {
        "@type": "FAQPage",
        "mainEntity": [
          {
            "@type": "Question",
            "name": "Which internet is best in Uganda?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Zuku Fiber is widely considered the best internet in Uganda due to its true symmetrical fiber optic speeds, 99.9% uptime SLA, and strictly unlimited plans with no data caps."
            }
          },
          {
            "@type": "Question",
            "name": "What is the cheapest internet in Uganda?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "For true unlimited fiber, Zuku Fiber offers some of the cheapest internet bundles in Uganda, starting at just UGX 75,000 per month for a 25 Mbps connection with zero data throttling."
            }
          },
          {
            "@type": "Question",
            "name": "Does Zuku Fiber have data caps?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "No, Zuku Fiber Uganda offers truly unlimited internet without data caps. There is zero throttling, meaning your speed is guaranteed whether it's 2 PM or Friday at 9 PM."
            }
          },
          {
            "@type": "Question",
            "name": "How much is fiber internet in Uganda?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Fiber internet in Uganda with Zuku starts at UGX 75,000 for 25 Mbps, scaling up to UGX 199,000 for 200 Mbps. All plans include free professional installation and a free Wi-Fi router."
            }
          },
          {
            "@type": "Question",
            "name": "Which ISP has the best coverage in Kampala?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Zuku Fiber has excellent coverage across the capital. We are now live in major areas including Kololo, Ntinda, Naguru, Bugolobi, Muyenga, Kisaasi, Kyanja, Bukoto, Munyonyo, and the Entebbe Road corridor."
            }
          },
          {
            "@type": "Question",
            "name": "Is Zuku Fiber available in Ntinda?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Yes! Zuku Fiber is fully available in Ntinda, providing residents and businesses with the fastest internet in Uganda and lowest latency connections."
            }
          },
          {
            "@type": "Question",
            "name": "What is the fastest internet speed in Uganda?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "For residential and SMB users, Zuku Fiber provides up to 200 Mbps symmetrical speeds with a 5ms latency, making it the fastest home internet Uganda currently offers."
            }
          },
          {
            "@type": "Question",
            "name": "How do I pay for internet in Uganda?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "You can pay for Zuku Fiber easily via MTN MoMo, Airtel Money, bank transfer, or at walk-in agent locations across Kampala. There are no long-term contracts required."
            }
          }
        ]
      }
    ]
  };

  return (
    <main className="min-h-screen bg-[#0a0f1e] text-gray-300 font-sans selection:bg-blue-500/30">
      {/* Hero Section */}
      <section className="relative w-full pt-32 pb-20 overflow-hidden bg-gradient-to-b from-blue-900/20 to-[#0a0f1e]">
        <div className="max-w-7xl mx-auto px-4 relative z-10 flex flex-col items-center text-center">
          <div className="inline-block bg-white/10 text-white text-sm tracking-wide uppercase rounded-full px-4 py-1.5 mb-6 border border-white/10 shadow-lg backdrop-blur-sm">
            📡 Now live in Ntinda, Kampala
          </div>
          
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight max-w-4xl tracking-tight">
            The Fastest <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-blue-600">Internet in Ntinda Kampala</span>
          </h1>
          
          <p className="text-xl md:text-2xl font-semibold text-gray-200 mb-8 max-w-2xl">
            Experience the best fiber internet Uganda has to offer. Stop buffering and start surfing with reliable, unlimited internet for your Ntinda home or business.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 mb-12">
            <Link 
              href="https://wa.me/2560775260196" 
              className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-8 py-4 font-semibold transition-all duration-300 shadow-lg shadow-blue-600/20 text-lg flex items-center justify-center gap-2"
            >
              Get Connected via WhatsApp
            </Link>
            <Link 
              href="/#plans" 
              className="border border-white/20 text-white hover:bg-white/10 rounded-lg px-8 py-4 font-semibold transition-all duration-300 text-lg flex items-center justify-center"
            >
              View Pricing Plans
            </Link>
          </div>
          
          <div className="flex flex-wrap justify-center gap-4 text-sm font-medium text-white/90">
            <span className="flex items-center gap-2 bg-white/5 rounded-full px-4 py-2 border border-white/10 backdrop-blur-sm">
              ⚡ Free Installation
            </span>
            <span className="flex items-center gap-2 bg-white/5 rounded-full px-4 py-2 border border-white/10 backdrop-blur-sm">
              📡 Free Wi-Fi Router
            </span>
            <span className="flex items-center gap-2 bg-white/5 rounded-full px-4 py-2 border border-white/10 backdrop-blur-sm">
              📺 100+ TV Channels
            </span>
          </div>
        </div>
        
        {/* Decorative background elements */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-blue-600/10 rounded-full blur-[120px] -z-10 pointer-events-none"></div>
      </section>

      {/* Metrics Section */}
      <section className="border-y border-white/5 bg-white/[0.02]">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center divide-y md:divide-y-0 md:divide-x divide-white/10">
            <div className="px-4">
              <div className="text-4xl font-bold text-white mb-2">99.9%</div>
              <div className="text-sm uppercase tracking-wider text-gray-400">Guaranteed Uptime</div>
            </div>
            <div className="px-4 py-6 md:py-0">
              <div className="text-4xl font-bold text-white mb-2">200Mbps</div>
              <div className="text-sm uppercase tracking-wider text-gray-400">Max Symmetrical Speed</div>
            </div>
            <div className="px-4">
              <div className="text-4xl font-bold text-white mb-2">24/7</div>
              <div className="text-sm uppercase tracking-wider text-gray-400">Kampala-Based Support</div>
            </div>
          </div>
        </div>
      </section>

      {/* Content Section / Why Zuku */}
      <section className="py-24 max-w-7xl mx-auto px-4">
        <div className="mb-16 text-center max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Why We Are the Best Internet Provider Uganda Has to Offer</h2>
          <p className="text-lg text-gray-300">
            Residents searching for the best WiFi in Kampala consistently choose Zuku Fiber. Whether you need the best internet for working from home Uganda or reliable connectivity for your family, our infrastructure crushes the competition.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="bg-white/5 border border-white/10 rounded-2xl p-8 hover:bg-white/10 transition-colors">
            <div className="text-4xl mb-4">🚀</div>
            <h3 className="text-xl font-bold text-white mb-3">Zero Throttling, Ever</h3>
            <p className="text-gray-400">
              Unlike other internet providers Uganda has, we never slow down your speeds. Your internet speed is guaranteed whether it&apos;s a busy Friday evening at 9pm or early morning. Enjoy true unlimited internet Uganda style.
            </p>
          </div>
          <div className="bg-white/5 border border-white/10 rounded-2xl p-8 hover:bg-white/10 transition-colors">
            <div className="text-4xl mb-4">⚖️</div>
            <h3 className="text-xl font-bold text-white mb-3">Symmetrical Speeds</h3>
            <p className="text-gray-400">
              Upload exactly as fast as you download. With an incredible 5ms latency, it&apos;s the fastest internet Uganda has for video calls, gaming, and massive file transfers.
            </p>
          </div>
          <div className="bg-white/5 border border-white/10 rounded-2xl p-8 hover:bg-white/10 transition-colors">
            <div className="text-4xl mb-4">🛡️</div>
            <h3 className="text-xl font-bold text-white mb-3">DDoS & DNS Protection</h3>
            <p className="text-gray-400">
              We offer built-in network security, preventing attacks before they reach you. It&apos;s the most secure home internet Uganda provides, backed by our 24/7 Kampala-based engineers.
            </p>
          </div>
        </div>
        
        <div className="prose prose-invert max-w-4xl mx-auto">
          <p className="text-lg mb-6 leading-relaxed">
            Finding reliable internet in Kampala used to be a challenge. But today, our expansion brings world-class fiber internet Kampala networks directly to your door. We are expanding rapidly, now prominently serving areas beyond just Ntinda. If you live or work in <strong>Kololo, Naguru, Bugolobi, Muyenga, Kisaasi, Kyanja, Bukoto, Munyonyo, or the Entebbe Road corridor</strong>, you can experience the Zuku Fiber difference.
          </p>
          <p className="text-lg leading-relaxed">
            We are consistently ranked as the best ISP Uganda wide because we listen to our users. Forget frustrating data caps and slow loading times. With no restrictive contracts, you get the cheapest internet bundles Uganda has seen for true, unlimited, cap-free fiber. 
          </p>
        </div>
      </section>

      {/* Comparison Table Section */}
      <section className="py-24 bg-black/40 border-y border-white/5">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16 space-y-4 max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-white">Internet Providers Uganda Comparison</h2>
            <p className="text-lg text-gray-400">
              See how Zuku Fiber stacks up in the ultimate Airtel vs MTN vs Zuku Uganda showdown. When searching for the best unlimited internet Uganda 2026, the choice is clear.
            </p>
          </div>
          
          <div className="w-full overflow-x-auto rounded-2xl border border-white/10 shadow-2xl bg-[#0a0f1e]">
            <table className="w-full text-left border-collapse min-w-[900px]">
              <thead>
                <tr className="bg-white/5 border-b border-white/10 text-white font-semibold">
                  <th className="p-5">Provider</th>
                  <th className="p-5">Technology</th>
                  <th className="p-5">Starting Price</th>
                  <th className="p-5">Speed</th>
                  <th className="p-5">Data Cap</th>
                  <th className="p-5">Throttling</th>
                  <th className="p-5">Free Installation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-gray-300">
                <tr className="bg-blue-600/10 hover:bg-blue-600/20 transition-colors border-l-4 border-blue-500">
                  <td className="p-5 font-bold text-white flex items-center gap-2">
                    <span className="text-blue-500">★</span> Zuku Fiber
                  </td>
                  <td className="p-5">Pure Fiber Optic</td>
                  <td className="p-5 text-white font-semibold flex flex-col">
                    UGX 75,000/mo
                    <span className="text-xs text-blue-400 font-normal">Best Value</span>
                  </td>
                  <td className="p-5">Up to 200 Mbps</td>
                  <td className="p-5 text-green-400 font-medium">Strictly Unlimited</td>
                  <td className="p-5 text-green-400 font-medium">None ever</td>
                  <td className="p-5">✅ Yes</td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="p-5 font-medium text-white">MTN Uganda (WakaNet)</td>
                  <td className="p-5">5G / Fiber</td>
                  <td className="p-5">UGX 130,000/mo</td>
                  <td className="p-5">Varies</td>
                  <td className="p-5 text-yellow-500">Fair Usage Applies</td>
                  <td className="p-5 text-red-400">Yes (during peak)</td>
                  <td className="p-5">❌ Paid</td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="p-5 font-medium text-white">Airtel Uganda</td>
                  <td className="p-5">5G / Mobile Broadband</td>
                  <td className="p-5">UGX 150,000/mo</td>
                  <td className="p-5">Varies</td>
                  <td className="p-5 text-red-400">Volume Caps Apply</td>
                  <td className="p-5 text-red-400">Yes</td>
                  <td className="p-5">❌ Paid Router</td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="p-5 font-medium text-white">Roke Telkom</td>
                  <td className="p-5">Wireless / Fiber</td>
                  <td className="p-5">UGX 112,000/mo</td>
                  <td className="p-5">Up to 100 Mbps</td>
                  <td className="p-5 text-yellow-500">Time-based caps</td>
                  <td className="p-5 text-red-400">Yes (Roke Plus)</td>
                  <td className="p-5">❌ Paid usually</td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="p-5 font-medium text-white">Faibanet</td>
                  <td className="p-5">Fiber</td>
                  <td className="p-5">UGX 100,000/mo</td>
                  <td className="p-5">Up to 50 Mbps</td>
                  <td className="p-5 text-green-400">Unlimited</td>
                  <td className="p-5 text-yellow-500">Unclear</td>
                  <td className="p-5">❌ Often paid</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div className="mt-8 text-center text-sm text-gray-500">
            * Comparison based on standard home internet plans. Discover the fiber internet Uganda price that fits your budget by checking our <Link href="/#plans" className="text-blue-400 hover:underline">detailed pricing section</Link>.
          </div>
        </div>
      </section>

      {/* Pricing Teaser / Plans */}
      <section className="py-24 max-w-7xl mx-auto px-4" id="plans">
        <div className="text-center mb-16">
          <div className="inline-block bg-blue-500/10 text-blue-400 text-sm tracking-wide uppercase rounded-full px-4 py-1.5 mb-4 shadow-sm">
            Simple, Transparent Pricing
          </div>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">Unbeatable Value for Ntinda</h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Choose a plan that fits your family or business. All packages include a free Wi-Fi router, free installation, and 100+ TV channels.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { speed: "25 Mbps", price: "75,000", users: "1-3 Devices", popular: false },
            { speed: "50 Mbps", price: "89,400", users: "4-6 Devices", popular: true },
            { speed: "100 Mbps", price: "110,000", users: "7-10 Devices", popular: false },
            { speed: "200 Mbps", price: "199,000", users: "10+ Devices", popular: false }
          ].map((plan, i) => (
            <div key={i} className={`relative bg-white/5 border rounded-2xl p-8 flex flex-col h-full transition-all hover:bg-white/10 align-top ${plan.popular ? 'border-blue-500 shadow-[0_0_30px_rgba(59,130,246,0.15)]' : 'border-white/10'}`}>
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-xs font-bold uppercase tracking-wider py-1.5 px-4 rounded-full">
                  Most Popular
                </div>
              )}
              <h3 className="text-2xl font-bold text-white mb-2">{plan.speed}</h3>
              <div className="text-4xl font-extrabold text-white mb-6 tracking-tight">
                <span className="text-xl font-normal text-gray-400 mr-1">UGX</span>
                {plan.price}
                <span className="text-base font-normal text-gray-400 block mt-1">/ month</span>
              </div>
              <ul className="space-y-3 mb-8 flex-grow">
                {['Unlimited Data', 'Zero Throttling', 'True Symmetrical Speed', `Best for ${plan.users}`].map((feature, j) => (
                  <li key={j} className="flex items-start text-gray-300">
                    <svg className="w-5 h-5 text-blue-500 mr-3 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    {feature}
                  </li>
                ))}
              </ul>
              <Link 
                href="https://wa.me/2560775260196" 
                className={`w-full py-3 rounded-lg font-semibold text-center transition-colors ${plan.popular ? 'bg-blue-600 hover:bg-blue-700 text-white' : 'bg-white/10 hover:bg-white/20 text-white'}`}
              >
                Select Plan
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24 bg-black/40 border-t border-white/5" id="faq">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">Frequently Asked Questions</h2>
            <p className="text-lg text-gray-400">Everything you need to know about getting the best internet network in Kampala.</p>
          </div>
          
          <div className="space-y-4">
            {[
              { q: "Which internet is best in Uganda?", a: "Zuku Fiber is widely considered the best internet in Uganda due to its true symmetrical fiber optic speeds, 99.9% uptime SLA, and strictly unlimited plans with no data caps." },
              { q: "What is the cheapest internet in Uganda?", a: "For true unlimited fiber, Zuku Fiber offers some of the cheapest internet bundles in Uganda, starting at just UGX 75,000 per month for a 25 Mbps connection with zero data throttling." },
              { q: "Does Zuku Fiber have data caps?", a: "No, Zuku Fiber Uganda offers truly unlimited internet without data caps. There is zero throttling, meaning your speed is guaranteed whether it's 2 PM or Friday at 9 PM." },
              { q: "How much is fiber internet in Uganda?", a: "Fiber internet in Uganda with Zuku starts at UGX 75,000 for 25 Mbps, scaling up to UGX 199,000 for 200 Mbps. All plans include free professional installation and a free Wi-Fi router." },
              { q: "Which ISP has the best coverage in Kampala?", a: "Zuku Fiber has excellent coverage across the capital. We are now live in major areas including Kololo, Ntinda, Naguru, Bugolobi, Muyenga, Kisaasi, Kyanja, Bukoto, Munyonyo, and the Entebbe Road corridor." },
              { q: "Is Zuku Fiber available in Ntinda?", a: "Yes! Zuku Fiber is fully available in Ntinda, providing residents and businesses with the fastest internet in Uganda and lowest latency connections." },
              { q: "What is the fastest internet speed in Uganda?", a: "For residential and SMB users, Zuku Fiber provides up to 200 Mbps symmetrical speeds with a 5ms latency, making it the fastest home internet Uganda currently offers." },
              { q: "How do I pay for internet in Uganda?", a: "You can pay for Zuku Fiber easily via MTN MoMo, Airtel Money, bank transfer, or at walk-in agent locations across Kampala. There are no long-term contracts required." }
            ].map((faq, i) => (
              <details key={i} className="group bg-white/5 border border-white/10 rounded-xl overflow-hidden [&_summary::-webkit-details-marker]:hidden">
                <summary className="flex items-center justify-between cursor-pointer p-6 font-semibold text-white hover:bg-white/[0.07] transition-colors">
                  <span className="text-lg pr-4">{faq.q}</span>
                  <span className="transition group-open:rotate-180 bg-white/10 rounded-full p-1 text-gray-300">
                    <svg fill="none" height="24" shapeRendering="geometricPrecision" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" viewBox="0 0 24 24" width="24"><path d="M6 9l6 6 6-6"></path></svg>
                  </span>
                </summary>
                <div className="px-6 pb-6 pt-4 text-gray-400 text-base leading-relaxed border-t border-white/5 mt-2">
                  {faq.a}
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* Full Width CTA CTA */}
      <section className="relative py-28 overflow-hidden bg-blue-900 border-t border-blue-500/20 text-center">
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0f1e] to-transparent opacity-80"></div>
        
        <div className="relative max-w-4xl mx-auto px-4 z-10">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 tracking-tight">Ready for the ultimate internet upgrade?</h2>
          <p className="text-xl text-blue-100 mb-10 max-w-2xl mx-auto font-medium">
            Join thousands of happy customers in Ntinda enjoying internet without data cap Uganda. No contracts, strict SLA guarantees.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link 
              href="https://wa.me/2560775260196" 
              className="bg-white text-blue-900 hover:bg-gray-100 rounded-lg px-8 py-4 font-bold transition-transform hover:-translate-y-0.5 shadow-xl text-lg flex items-center justify-center gap-2"
            >
              Sign Up via WhatsApp
            </Link>
            <Link 
              href="/#features" 
              className="border border-white/30 text-white hover:bg-white/10 rounded-lg px-8 py-4 font-semibold transition-all duration-300 text-lg flex items-center justify-center"
            >
              Learn More
            </Link>
          </div>
        </div>
      </section>

      {/* Structured Data JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
    </main>
  );
}
