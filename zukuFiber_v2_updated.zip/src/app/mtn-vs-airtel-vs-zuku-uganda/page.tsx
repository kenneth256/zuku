import type { Metadata } from 'next';
import Link from 'next/link';

export function generateMetadata(): Metadata {
  return {
    title: 'MTN vs Airtel vs Zuku Uganda 2026 | Best ISP Comparison',
    description: 'MTN vs Airtel vs Zuku Uganda — the definitive 2026 ISP comparison. See speeds, prices, data caps and throttling. Zuku Fiber wins from UGX 75,000/mo.',
    keywords: [
      'Airtel vs MTN vs Zuku Uganda',
      'best internet provider Uganda',
      'best internet in Uganda',
      'fastest internet Uganda',
      'internet providers Uganda comparison',
      'best ISP Uganda',
      'MTN Uganda internet',
      'Airtel Uganda internet',
      'fiber internet Kampala',
      'unlimited internet Uganda',
      'best unlimited internet Uganda 2026',
      'cheapest internet bundles Uganda',
      'Zuku Fiber Uganda',
      'home internet Uganda',
      'best WiFi in Kampala',
    ],
    openGraph: {
      title: 'MTN vs Airtel vs Zuku Uganda 2026 | Best ISP Comparison',
      description: 'MTN vs Airtel vs Zuku Uganda — the definitive 2026 ISP comparison. Zuku Fiber wins on speed, price, and unlimited data from UGX 75,000/mo.',
      url: 'https://zukufiberuganda.vercel.app/mtn-vs-airtel-vs-zuku-uganda',
      siteName: 'Zuku Fiber Uganda',
    },
    alternates: {
      canonical: 'https://zukufiberuganda.vercel.app/mtn-vs-airtel-vs-zuku-uganda',
    },
  };
}

export default function MtnVsAirtelVsZukuPage() {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@graph': [
      {
        '@type': 'LocalBusiness',
        name: 'Zuku Fiber Uganda',
        url: 'https://zukufiberuganda.vercel.app/',
        telephone: '0775 260 196',
        address: { '@type': 'PostalAddress', streetAddress: 'Diamond Trust Building', addressLocality: 'Kampala', addressCountry: 'Uganda' },
        geo: { '@type': 'GeoCoordinates', latitude: 0.3476, longitude: 32.5825 },
      },
      {
        '@type': 'BreadcrumbList',
        itemListElement: [
          { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://zukufiberuganda.vercel.app/' },
          { '@type': 'ListItem', position: 2, name: 'MTN vs Airtel vs Zuku Uganda', item: 'https://zukufiberuganda.vercel.app/mtn-vs-airtel-vs-zuku-uganda' },
        ],
      },
      {
        '@type': 'FAQPage',
        mainEntity: [
          { '@type': 'Question', name: 'Which is better — MTN, Airtel, or Zuku in Uganda?', acceptedAnswer: { '@type': 'Answer', text: 'For home internet in Kampala, Zuku Fiber is the best option. It uses dedicated fiber optic infrastructure, has no data caps, no throttling, and starts at UGX 75,000/month with free installation.' } },
          { '@type': 'Question', name: 'Does MTN Uganda throttle internet speeds?', acceptedAnswer: { '@type': 'Answer', text: 'Yes. MTN Uganda WakaNet applies fair usage policies that can throttle your speeds during peak hours or after a usage threshold. Zuku Fiber does not throttle at any time.' } },
          { '@type': 'Question', name: 'Is Airtel internet unlimited in Uganda?', acceptedAnswer: { '@type': 'Answer', text: 'Airtel Uganda applies volume caps on most plans. After a data threshold is reached, speeds are reduced. Zuku Fiber offers genuinely unlimited internet with no caps whatsoever.' } },
          { '@type': 'Question', name: 'Which internet provider has the best coverage in Kampala?', acceptedAnswer: { '@type': 'Answer', text: 'Zuku Fiber covers major Kampala areas including Kololo, Ntinda, Naguru, Bugolobi, Muyenga, Kisaasi, Kyanja, Bukoto, Munyonyo, and Entebbe Road.' } },
          { '@type': 'Question', name: 'What is the cheapest internet in Uganda?', acceptedAnswer: { '@type': 'Answer', text: 'Zuku Fiber offers truly unlimited fiber internet from UGX 75,000/month — cheaper per megabit than MTN or Airtel when you factor in data caps and fair usage throttling.' } },
          { '@type': 'Question', name: 'How do I switch from MTN or Airtel to Zuku Fiber?', acceptedAnswer: { '@type': 'Answer', text: 'Simply WhatsApp Zuku Fiber on 0775 260 196 or call us. We\'ll schedule a free installation at a time that suits you. Most homes go live within 24 hours.' } },
          { '@type': 'Question', name: 'What technology does Zuku Fiber use?', acceptedAnswer: { '@type': 'Answer', text: 'Zuku Fiber uses pure fiber optic cables delivering true symmetrical speeds up to 200 Mbps with 5ms latency — unlike MTN and Airtel which rely on wireless 5G/4G broadband.' } },
          { '@type': 'Question', name: 'Can I use mobile money to pay for Zuku Fiber?', acceptedAnswer: { '@type': 'Answer', text: 'Yes. Zuku Fiber accepts MTN MoMo, Airtel Money, bank transfer, and walk-in agent payments at locations across Kampala.' } },
        ],
      },
    ],
  };

  const providers = [
    { name: 'Zuku Fiber', tech: 'Pure Fiber Optic', price: 'UGX 75,000/mo', speed: '25–200 Mbps', symmetrical: '✅ Yes', cap: 'None — Unlimited', throttle: 'Never', install: 'Free', router: 'Free', support: '24/7 Kampala', winner: true },
    { name: 'MTN WakaNet', tech: '5G / Fiber', price: 'UGX 130,000/mo', speed: 'Up to 100 Mbps', symmetrical: '❌ No', cap: 'Fair Usage Policy', throttle: 'Yes (peak)', install: 'Paid', router: 'Paid', support: 'Call centre', winner: false },
    { name: 'Airtel Uganda', tech: '5G / 4G Broadband', price: 'UGX 150,000/mo', speed: 'Varies', symmetrical: '❌ No', cap: 'Volume Caps', throttle: 'Yes', install: 'Paid', router: 'Paid', support: 'Call centre', winner: false },
    { name: 'Roke Telkom', tech: 'Wireless / Fiber', price: 'UGX 112,000/mo', speed: 'Up to 100 Mbps', symmetrical: '⚠️ Partial', cap: 'Time-based caps', throttle: 'Yes', install: 'Usually paid', router: 'Varies', support: 'Business hours', winner: false },
    { name: 'Faibanet', tech: 'Fiber', price: 'UGX 100,000/mo', speed: 'Up to 50 Mbps', symmetrical: '⚠️ Partial', cap: 'Unlimited', throttle: 'Unclear', install: 'Often paid', router: 'Varies', support: 'Limited', winner: false },
  ];

  return (
    <main className="min-h-screen bg-[#0a0f1e] text-gray-300 font-sans selection:bg-blue-500/30">

      {/* Hero */}
      <section className="relative w-full pt-32 pb-20 overflow-hidden bg-gradient-to-b from-blue-900/20 to-[#0a0f1e]">
        <div className="max-w-7xl mx-auto px-4 relative z-10 flex flex-col items-center text-center">
          <div className="inline-block bg-white/10 text-white text-sm tracking-wide uppercase rounded-full px-4 py-1.5 mb-6 border border-white/10 backdrop-blur-sm">
            ⚔️ Head-to-Head ISP Comparison — Uganda 2026
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight max-w-5xl tracking-tight">
            MTN vs Airtel vs{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-blue-600">Zuku Uganda</span>
            : Which is Best?
          </h1>
          <p className="text-xl text-gray-200 mb-8 max-w-3xl">
            We put Uganda&apos;s biggest internet providers head-to-head on speed, price, data caps, throttling, and support. The best internet provider Uganda wide has a clear winner.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 mb-10">
            <Link href="https://wa.me/2560775260196" className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-8 py-4 font-semibold transition-all shadow-lg shadow-blue-600/20 text-lg">
              Switch to Zuku Fiber Today
            </Link>
            <Link href="/#plans" className="border border-white/20 text-white hover:bg-white/10 rounded-lg px-8 py-4 font-semibold transition-all text-lg">
              View Plans
            </Link>
          </div>
        </div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-blue-600/10 rounded-full blur-[120px] -z-10 pointer-events-none" />
      </section>

      {/* Verdict cards */}
      <section className="py-16 max-w-7xl mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-bold text-white mb-10 text-center">The Short Verdict</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { provider: 'Zuku Fiber', verdict: '🏆 Winner', color: 'border-blue-500 bg-blue-600/10', detail: 'Best for home internet in Kampala. Dedicated fiber, zero throttling, free installation, and the cheapest true-unlimited plans in Uganda.' },
            { provider: 'MTN WakaNet', verdict: '⚠️ Good for Mobile', color: 'border-yellow-500/40 bg-yellow-500/5', detail: 'Best for on-the-go mobile internet. Fair usage policy means speeds drop for heavy home users. Not ideal as a primary home connection.' },
            { provider: 'Airtel Uganda', verdict: '⚠️ Good for Bundles', color: 'border-orange-500/40 bg-orange-500/5', detail: 'Affordable short-term data bundles. Volume caps and throttling make it unsuitable for unlimited home internet use.' },
          ].map(v => (
            <div key={v.provider} className={`border rounded-2xl p-8 ${v.color}`}>
              <div className="text-2xl font-bold text-white mb-1">{v.provider}</div>
              <div className="text-sm font-semibold mb-4">{v.verdict}</div>
              <p className="text-gray-400 leading-relaxed">{v.detail}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Detailed comparison table */}
      <section className="py-16 bg-black/40 border-y border-white/5">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 text-center">Full Comparison Table</h2>
          <p className="text-center text-gray-400 mb-12 max-w-2xl mx-auto">Every major factor that affects your daily internet experience in Uganda, side by side.</p>
          <div className="w-full overflow-x-auto rounded-2xl border border-white/10 bg-[#0a0f1e]">
            <table className="w-full text-left border-collapse min-w-[1000px]">
              <thead>
                <tr className="bg-white/5 border-b border-white/10 text-white font-semibold text-sm uppercase tracking-wide">
                  <th className="p-4">Feature</th>
                  {providers.map(p => (
                    <th key={p.name} className={`p-4 ${p.winner ? 'text-blue-400' : ''}`}>
                      {p.winner ? '★ ' : ''}{p.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-sm">
                {[
                  { label: 'Technology', key: 'tech' as const },
                  { label: 'Starting Price', key: 'price' as const },
                  { label: 'Max Speed', key: 'speed' as const },
                  { label: 'Symmetrical', key: 'symmetrical' as const },
                  { label: 'Data Cap', key: 'cap' as const },
                  { label: 'Throttling', key: 'throttle' as const },
                  { label: 'Installation', key: 'install' as const },
                  { label: 'Router', key: 'router' as const },
                  { label: 'Support', key: 'support' as const },
                ].map(row => (
                  <tr key={row.label} className="hover:bg-white/[0.03] transition-colors">
                    <td className="p-4 font-semibold text-white/70 text-xs uppercase tracking-wide">{row.label}</td>
                    {providers.map(p => (
                      <td key={p.name} className={`p-4 ${p.winner ? 'text-white font-medium bg-blue-600/5' : 'text-gray-300'}`}>
                        {p[row.key]}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Deep dive sections */}
      <section className="py-24 max-w-7xl mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-16 text-center">Deep Dive: What the Numbers Actually Mean</h2>
        <div className="space-y-16 max-w-4xl mx-auto">

          <div>
            <h3 className="text-2xl font-bold text-white mb-4">🔌 Technology: Fiber vs Wireless</h3>
            <p className="text-gray-300 leading-relaxed mb-4">
              MTN Uganda WakaNet and Airtel Uganda both rely primarily on wireless 5G and 4G infrastructure. This means your connection is shared with every mobile phone in your neighbourhood — and speeds suffer when hundreds of people get home from work in the evening. If you live in Ntinda, Naguru, Bugolobi, or Kololo, you&apos;ve almost certainly experienced this slowdown between 7–10 PM.
            </p>
            <p className="text-gray-300 leading-relaxed">
              Zuku Fiber runs a dedicated fiber optic cable to your home. Your connection is not shared with your neighbours. This is why we can guarantee the same speed at 9 PM on a Friday as 9 AM on a Tuesday — because the infrastructure simply works differently. This makes Zuku Fiber the fastest internet Uganda has for home use.
            </p>
          </div>

          <div>
            <h3 className="text-2xl font-bold text-white mb-4">📊 Data Caps &amp; Throttling</h3>
            <p className="text-gray-300 leading-relaxed mb-4">
              Both MTN WakaNet and Airtel Uganda apply fair usage policies. Read the fine print and you&apos;ll find phrases like &quot;speeds may be reduced after X GB&quot; or &quot;during periods of network congestion.&quot; This is throttling — and it turns a 100 Mbps plan into something much slower in practice.
            </p>
            <p className="text-gray-300 leading-relaxed">
              Zuku Fiber&apos;s plans are genuinely unlimited. No data caps, no fair usage clauses, no throttling. Internet without data cap Uganda — that&apos;s our standard, not a premium add-on. This is especially critical if you are looking for the best internet for working from home Uganda, where video calls and large file transfers demand consistent speeds.
            </p>
          </div>

          <div>
            <h3 className="text-2xl font-bold text-white mb-4">💸 Real Cost Comparison</h3>
            <p className="text-gray-300 leading-relaxed mb-4">
              On the surface, MTN and Airtel plans might appear cheaper. But factor in: a paid router, paid installation, and the cost of buying extra data bundles when you hit your cap — and Zuku Fiber at UGX 75,000/month becomes clearly the cheapest internet bundles Uganda offers for unlimited use.
            </p>
            <p className="text-gray-300 leading-relaxed">
              With Zuku, the price you see is the price you pay. No installation fee, no router fee, no data top-up charges. Just fast fiber internet Kampala homes can rely on.
            </p>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-24 bg-black/40 border-t border-white/5">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Common Questions</h2>
            <p className="text-gray-400">Answers to the most common questions when comparing Uganda&apos;s ISPs.</p>
          </div>
          <div className="space-y-4">
            {[
              { q: 'Which is better — MTN, Airtel, or Zuku in Uganda?', a: 'For home internet in Kampala, Zuku Fiber is the best option. It uses dedicated fiber optic infrastructure, has no data caps, no throttling, and starts at UGX 75,000/month with free installation.' },
              { q: 'Does MTN Uganda throttle internet speeds?', a: 'Yes. MTN Uganda WakaNet applies fair usage policies that can throttle your speeds during peak hours or after a usage threshold. Zuku Fiber does not throttle at any time.' },
              { q: 'Is Airtel internet unlimited in Uganda?', a: 'Airtel Uganda applies volume caps on most plans. After a data threshold is reached, speeds are reduced. Zuku Fiber offers genuinely unlimited internet with no caps whatsoever.' },
              { q: 'Which internet provider has the best coverage in Kampala?', a: 'Zuku Fiber covers major Kampala areas including Kololo, Ntinda, Naguru, Bugolobi, Muyenga, Kisaasi, Kyanja, Bukoto, Munyonyo, and Entebbe Road.' },
              { q: 'What is the cheapest internet in Uganda?', a: 'Zuku Fiber offers truly unlimited fiber internet from UGX 75,000/month — cheaper per megabit than MTN or Airtel when you factor in data caps and fair usage throttling.' },
              { q: 'How do I switch from MTN or Airtel to Zuku Fiber?', a: 'Simply WhatsApp Zuku Fiber on 0775 260 196 or call us. We\'ll schedule a free installation at a time that suits you. Most homes go live within 24 hours.' },
              { q: 'What technology does Zuku Fiber use?', a: 'Zuku Fiber uses pure fiber optic cables delivering true symmetrical speeds up to 200 Mbps with 5ms latency — unlike MTN and Airtel which rely on wireless 5G/4G broadband.' },
              { q: 'Can I use mobile money to pay for Zuku Fiber?', a: 'Yes. Zuku Fiber accepts MTN MoMo, Airtel Money, bank transfer, and walk-in agent payments at locations across Kampala.' },
            ].map(faq => (
              <details key={faq.q} className="group bg-white/5 border border-white/10 rounded-xl overflow-hidden [&_summary::-webkit-details-marker]:hidden">
                <summary className="flex items-center justify-between cursor-pointer p-6 font-semibold text-white hover:bg-white/[0.07] transition-colors">
                  <span className="pr-4">{faq.q}</span>
                  <span className="transition group-open:rotate-180 bg-white/10 rounded-full p-1 shrink-0">
                    <svg fill="none" height="20" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5" width="20"><path d="M6 9l6 6 6-6" /></svg>
                  </span>
                </summary>
                <div className="px-6 pb-6 pt-2 text-gray-400 leading-relaxed border-t border-white/5">{faq.a}</div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative py-28 overflow-hidden bg-blue-900 border-t border-blue-500/20 text-center">
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0f1e] to-transparent opacity-80" />
        <div className="relative max-w-4xl mx-auto px-4 z-10">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Stop settling. Switch to Uganda&apos;s best.</h2>
          <p className="text-xl text-blue-100 mb-10 max-w-2xl mx-auto">
            Free installation. Free router. Free TV. Starting at UGX 75,000/month. No contracts. Same-day activation available across Kampala.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="https://wa.me/2560775260196" className="bg-white text-blue-900 hover:bg-gray-100 rounded-lg px-8 py-4 font-bold shadow-xl text-lg transition-all hover:-translate-y-0.5">
              Sign Up via WhatsApp
            </Link>
            <Link href="tel:+2560775260196" className="border border-white/30 text-white hover:bg-white/10 rounded-lg px-8 py-4 font-semibold text-lg transition-all">
              Call 0775 260 196
            </Link>
          </div>
        </div>
      </section>

      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
    </main>
  );
}
